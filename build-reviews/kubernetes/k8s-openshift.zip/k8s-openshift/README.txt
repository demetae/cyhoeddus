Kubernetes / OpenShift Project Security Review - Failure Focused

Purpose
-------
Namespace/project-scoped security review using Kubernetes and OpenShift policy themes.
Directly observed risky configuration is reported as FAIL. Items that cannot be fully
assessed with namespace-only access remain INFO or SKIP rather than being treated as PASS.

Run on Kali / Bash
------------------
chmod +x k8s_openshift_project_audit_failure_focused.sh

./k8s_openshift_project_audit_failure_focused.sh \
  --namespace <project-or-namespace> \
  --kube-cmd oc \
  --output ./reports

Outputs
-------
reports/failures.txt       Quick triage: explicit FAIL findings only
reports/cis_benchmark.html Full report: FAIL/PASS/INFO/SKIP/WARN
reports/cis_benchmark.csv  Full machine-readable CSV
reports/cis_benchmark.json Full machine-readable JSON

Interpretation
--------------
FAIL = a directly observed in-scope risky configuration/state.
PASS = the specific observable condition checked was not present / expected state observed.
INFO = useful evidence, but not enough to assert full benchmark compliance.
SKIP = current access/scope cannot evaluate the check.
WARN = manual review concern where retained by legacy checks.

The namespace/project value is supplied only at runtime and is not baked into the script.
