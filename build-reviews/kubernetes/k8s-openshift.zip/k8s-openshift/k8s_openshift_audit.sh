#!/usr/bin/env bash
# Kubernetes / OpenShift security review script (benchmark-informed)
# Failure-focused namespace/project mode; retains PASS/INFO/SKIP evidence in reports.
# Targets Kubernetes v1.32 - v1.34
#
# Usage: sudo ./cis_kubernetes_benchmark_v1.12.0.sh [options]
#
# Options:
#   --level 1|2          Only run checks for the specified level (default: both)
#   --section <N>        Only run section N (e.g., 1, 2, 3, 4, 5)
#   --node master|worker Run checks relevant to this node type
#   --target <user@ip>   Run checks against a remote host via SSH
#   --output <dir>       Write JSON, CSV, and HTML reports to <dir>
#   --json               Output JSON to stdout (legacy, still supported)
#   --no-color           Disable colored output
#   --kube-bench         Deploy kube-bench as Kubernetes Jobs to audit nodes
#                        from inside the cluster (like Kubernetes Goat)
#   --kubeconfig <path>  Path to the kubeconfig file to use for kubectl
#   --context <name>     Kubernetes context to use for kubectl
#   --kube-cmd <cmd>     Custom kubectl command/path (default: auto-detected)
#   --namespace <name>   Restrict API/policy checks to one namespace/project (Section 5 only)
#                        Directly observed risky states are FAIL; uncertain/manual items remain INFO/SKIP
#   --k9s                Launch k9s TUI at the end of execution
#   --kubectl            Launch interactive kubectl shell at the end of execution
#   -h, --help           Show this help message

set -euo pipefail

###############################################################################
# Kubernetes Distribution Detection
###############################################################################
# Detect the Kubernetes distribution and environment
detect_k8s_distro() {
  # Check for k3s
  if command -v k3s &>/dev/null || [[ -d /var/lib/rancher/k3s ]]; then
    echo "k3s"
    return
  fi
  
  # Check for RKE
  if [[ -d /var/lib/rancher/rke ]] || [[ -f /etc/rke/rke.yaml ]]; then
    echo "rke"
    return
  fi
  
  # Check for minikube
  if command -v minikube &>/dev/null || [[ -d ~/.minikube ]]; then
    echo "minikube"
    return
  fi
  
  # Check for kind (Kubernetes in Docker)
  if command -v kind &>/dev/null; then
    echo "kind"
    return
  fi
  
  # Check for microk8s
  if command -v microk8s &>/dev/null || [[ -d /snap/microk8s ]] || [[ -d /var/snap/microk8s ]]; then
    echo "microk8s"
    return
  fi
  
  # Check for OpenShift
  if command -v oc &>/dev/null || [[ -f /run/secrets/kubernetes.io/serviceaccount/ca.crt ]] && [[ -d /etc/origin ]]; then
    echo "openshift"
    return
  fi
  
  # Check for Rancher Desktop
  if [[ -d ~/.rd/k3s ]]; then
    echo "rancher-desktop"
    return
  fi
  
  # Check for AWS EKS
  if [[ -f /etc/eks/release ]]; then
    echo "eks"
    return
  fi
  
  # Check for Azure AKS
  if [[ -f /etc/aks-engine-release.txt ]] || grep -qi "aks" /proc/sys/kernel/osrelease 2>/dev/null; then
    echo "aks"
    return
  fi
  
  # Check for Google GKE
  if [[ -f /etc/google_compute_engine ]] || curl -s -H "Metadata-Flavor: Google" "http://169.254.169.254/computeMetadata/v1/?recursive=true" &>/dev/null; then
    echo "gke"
    return
  fi
  
  # Default to kubeadm/standard
  echo "kubeadm"
}

K8S_DISTRO=$(detect_k8s_distro)

###############################################################################
# Configuration & Defaults
###############################################################################
# Set file paths based on detected Kubernetes distribution
# Define all possible paths for each component across different k8s distributions
declare -a APISERVER_PATHS=(
  '/etc/kubernetes/manifests/kube-apiserver.yaml'
  '/var/lib/rancher/k3s/server/manifests/kube-apiserver.yaml'
  '/var/snap/microk8s/current/args/kube-apiserver.yaml'
)
declare -a CONTROLLER_MANAGER_PATHS=(
  '/etc/kubernetes/manifests/kube-controller-manager.yaml'
  '/var/lib/rancher/k3s/server/manifests/kube-controller-manager.yaml'
  '/var/snap/microk8s/current/args/kube-controller-manager.yaml'
)
declare -a SCHEDULER_PATHS=(
  '/etc/kubernetes/manifests/kube-scheduler.yaml'
  '/var/lib/rancher/k3s/server/manifests/kube-scheduler.yaml'
  '/var/snap/microk8s/current/args/kube-scheduler.yaml'
)
declare -a ETCD_PATHS=(
  '/etc/kubernetes/manifests/etcd.yaml'
  '/var/lib/rancher/k3s/server/manifests/etcd.yaml'
  '/var/snap/microk8s/current/args/etcd.yaml'
)
declare -a ADMIN_CONF_PATHS=(
  '/etc/kubernetes/admin.conf'
  '/etc/kubernetes/kubeconfig'
  '/etc/rancher/k3s/k3s.yaml'
  '/var/snap/microk8s/current/credentials/client.config'
)
declare -a PKI_DIR_PATHS=(
  '/etc/kubernetes/pki'
  '/var/lib/rancher/k3s/server/tls'
  '/var/snap/microk8s/current/certs'
)
declare -a ETCD_DATA_PATHS=(
  '/var/lib/etcd'
  '/var/lib/rancher/k3s/server/db'
  '/var/snap/microk8s/current/etcd'
)
declare -a CNI_CONF_PATHS=(
  '/etc/cni/net.d'
  '/var/lib/rancher/k3s/agent/etc/cni/net.d'
  '/var/snap/microk8s/current/args/cni-net.d'
)
declare -a KUBELET_CONFIG_PATHS=(
  '/var/lib/kubelet/config.yaml'
  '/etc/kubernetes/kubelet-config.yaml'
  '/var/lib/rancher/k3s/agent/etc/config/kubelet.config.yaml'
  '/var/snap/microk8s/current/args/kubelet-config.yaml'
)
declare -a SUPER_ADMIN_CONF_PATHS=(
  '/etc/kubernetes/super-admin.conf'
  '/etc/rancher/k3s/super-admin.conf'
  '/var/snap/microk8s/current/credentials/super-admin.conf'
)
declare -a SCHEDULER_CONF_PATHS=(
  '/etc/kubernetes/scheduler.conf'
  '/var/lib/rancher/k3s/server/scheduler.conf'
  '/var/snap/microk8s/current/args/scheduler.conf'
)
declare -a CONTROLLER_MANAGER_CONF_PATHS=(
  '/etc/kubernetes/controller-manager.conf'
  '/var/lib/rancher/k3s/server/controller-manager.conf'
  '/var/snap/microk8s/current/args/controller-manager.conf'
)
declare -a KUBELET_CONF_PATHS=(
  '/etc/kubernetes/kubelet.conf'
  '/var/lib/rancher/k3s/agent/kubelet.conf'
  '/var/snap/microk8s/current/credentials/kubelet.conf'
)
declare -a KUBELET_SVC_PATHS=(
  '/etc/systemd/system/kubelet.service.d/10-kubeadm.conf'
  '/etc/systemd/system/k3s-agent.service'
  '/etc/systemd/system/snap.microk8s.daemon-kubelet.service'
)

# Function to find first existing file from a list of candidates
find_first_existing_file() {
  local -a paths=("$@")
  for path in "${paths[@]}"; do
    if _test_f "$path"; then
      echo "$path"
      return 0
    fi
  done
  return 1
}

# Function to find first existing directory from a list of candidates
find_first_existing_dir() {
  local -a paths=("$@")
  for path in "${paths[@]}"; do
    if _test_d "$path"; then
      echo "$path"
      return 0
    fi
  done
  return 1
}

###############################################################################
# Color & Formatting
###############################################################################
USE_COLOR=true
JSON_OUTPUT=false
OUTPUT_DIR=""
FILTER_LEVEL=""
FILTER_SECTION=""
FILTER_NODE=""
TARGET_HOST=""
KUBE_BENCH=false
KUBECONFIG_PATH=""
KUBECONTEXT=""
KUBE_CMD=""
NAMESPACE=""
LAUNCH_K9S=false
LAUNCH_KUBECTL=false

# Counters
TOTAL=0
PASS=0
FAIL=0
WARN=0
INFO=0
SKIP=0

# JSON results array
JSON_RESULTS="["

# Collected results for CSV/HTML/JSON file output
# Each entry: "id|result|desc|detail|audit_output" (pipe-delimited)
declare -a ALL_RESULTS=()

# Global audit context - set by each section for automatic output on failures
_AUDIT_CONTEXT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --level) FILTER_LEVEL="$2"; shift 2 ;;
    --section) FILTER_SECTION="$2"; shift 2 ;;
    --node) FILTER_NODE="$2"; shift 2 ;;
    --target) TARGET_HOST="$2"; shift 2 ;;
    --output) OUTPUT_DIR="$2"; shift 2 ;;
    --json) JSON_OUTPUT=true; USE_COLOR=false; shift ;;
    --no-color) USE_COLOR=false; shift ;;
    --kube-bench) KUBE_BENCH=true; shift ;;
    --kubeconfig) KUBECONFIG_PATH="$2"; shift 2 ;;
    --context) KUBECONTEXT="$2"; shift 2 ;;
    --kube-cmd) KUBE_CMD="$2"; shift 2 ;;
    --namespace) NAMESPACE="$2"; shift 2 ;;
    --k9s) LAUNCH_K9S=true; shift ;;
    --kubectl) LAUNCH_KUBECTL=true; shift ;;
    -h|--help)
      sed -n '3,24p' "$0" | sed 's/^# //'
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# Namespace/project-scoped mode is intentionally limited to API/policy checks.
if [[ -n "$NAMESPACE" ]]; then
  if (( ${#NAMESPACE} > 63 )) || ! [[ "$NAMESPACE" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]]; then
    echo "Error: Invalid namespace/project name '$NAMESPACE'." >&2
    exit 1
  fi
  if [[ -n "$FILTER_SECTION" && "$FILTER_SECTION" != "5" ]]; then
    echo "Error: --namespace can only be used with Section 5 API/policy checks." >&2
    exit 1
  fi
  FILTER_SECTION="5"
  if $KUBE_BENCH; then
    echo "Error: --kube-bench cannot be used with --namespace; kube-bench requires cluster/node-level privileges." >&2
    exit 1
  fi
fi

if $USE_COLOR; then
  GREEN='\033[0;32m'
  RED='\033[0;31m'
  YELLOW='\033[0;33m'
  BLUE='\033[0;34m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
else
  GREEN='' RED='' YELLOW='' BLUE='' CYAN='' BOLD='' NC=''
fi

# Unit separator for ALL_RESULTS array (safe delimiter that won't appear in data)
_D=$'\x1f'

###############################################################################
# Remote Execution Support (SSH)
###############################################################################
# When --target is set, run commands on the remote host via SSH.
# When not set, run commands locally.
_SSH_OPTS=(-o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=10)

# Validate target and SSH connectivity
if [[ -n "$TARGET_HOST" ]]; then
  # Validate format: user@ip or just ip
  if [[ "$TARGET_HOST" =~ ^[a-zA-Z0-9._-]+(@ [a-zA-Z0-9._:-]+)?$ ]] || [[ "$TARGET_HOST" =~ ^[a-zA-Z0-9._-]+@[a-zA-Z0-9._:-]+$ ]] || [[ "$TARGET_HOST" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || [[ "$TARGET_HOST" =~ ^[a-zA-Z0-9._:-]+$ ]]; then
    : # valid
  else
    echo "Error: Invalid target format '$TARGET_HOST'. Use user@hostname or IP address." >&2
    exit 1
  fi
  if ! ssh "${_SSH_OPTS[@]}" "$TARGET_HOST" 'echo ok' &>/dev/null; then
    echo "Error: Cannot connect to $TARGET_HOST via SSH." >&2
    echo "Ensure SSH key-based authentication is configured (password prompts won't work)." >&2
    exit 1
  fi
fi

# Run a command locally or on the remote target via SSH
_rcmd() {
  local cmd="$1"
  local wrapper=""
  # Define a local function to wrap kubectl calls if we have custom options or a custom binary
  if [[ -n "${KUBECONFIG_PATH:-}" || -n "${KUBECONTEXT:-}" || "${KUBE_CMD:-kubectl}" != "kubectl" ]]; then
    wrapper="kubectl() { command ${KUBE_CMD:-kubectl}"
    if [[ -n "${KUBECONFIG_PATH:-}" ]]; then
      wrapper="$wrapper --kubeconfig='$KUBECONFIG_PATH'"
    fi
    if [[ -n "${KUBECONTEXT:-}" ]]; then
      wrapper="$wrapper --context='$KUBECONTEXT'"
    fi
    wrapper="$wrapper \"\$@\"; }; "
  fi
  cmd="$wrapper$cmd"

  if [[ -n "$TARGET_HOST" ]]; then
    ssh "${_SSH_OPTS[@]}" "$TARGET_HOST" bash -c "$cmd"
  else
    eval "$cmd"
  fi
}

# Test if a file exists (remotely or locally)
_test_f() {
  _rcmd "[[ -f '$1' ]]" 2>/dev/null
}

# Test if a directory exists (remotely or locally)
_test_d() {
  _rcmd "[[ -d '$1' ]]" 2>/dev/null
}

# Run stat on a file (remotely or locally)
_stat() {
  _rcmd "stat $*"
}

# Run find (remotely or locally)
_find() {
  _rcmd "find $*"
}

# Check if a command exists (remotely or locally)
_has_cmd() {
  _rcmd "command -v '$1'" &>/dev/null
}

# Auto-detect kubectl commands
detect_kubectl_cmd() {
  if _has_cmd kubectl; then
    echo "kubectl"
  elif _has_cmd k3s; then
    echo "k3s kubectl"
  elif _has_cmd microk8s; then
    echo "microk8s kubectl"
  else
    echo "kubectl"
  fi
}

has_kubectl() {
  local cmd_base="${KUBE_CMD%% *}"
  _has_cmd "$cmd_base"
}

if [[ -z "${KUBE_CMD:-}" ]]; then
  KUBE_CMD=$(detect_kubectl_cmd)
fi

###############################################################################
# Initialize component paths after CLI/SSH configuration is available.
# Namespace mode only runs Section 5 API checks, so host paths are not needed.
###############################################################################
APISERVER_POD_SPEC=""
CONTROLLER_MANAGER_POD_SPEC=""
SCHEDULER_POD_SPEC=""
ETCD_POD_SPEC=""
ADMIN_CONF=""
SUPER_ADMIN_CONF=""
SCHEDULER_CONF=""
CONTROLLER_MANAGER_CONF=""
PKI_DIR=""
ETCD_DATA_DIR=""
CNI_CONF_DIR=""
KUBELET_CONFIG_YAML=""
KUBELET_CONF=""
KUBELET_SVC=""

if [[ -z "$NAMESPACE" ]]; then
  APISERVER_POD_SPEC=$(find_first_existing_file "${APISERVER_PATHS[@]}" || true)
  CONTROLLER_MANAGER_POD_SPEC=$(find_first_existing_file "${CONTROLLER_MANAGER_PATHS[@]}" || true)
  SCHEDULER_POD_SPEC=$(find_first_existing_file "${SCHEDULER_PATHS[@]}" || true)
  ETCD_POD_SPEC=$(find_first_existing_file "${ETCD_PATHS[@]}" || true)
  ADMIN_CONF=$(find_first_existing_file "${ADMIN_CONF_PATHS[@]}" || true)
  SUPER_ADMIN_CONF=$(find_first_existing_file "${SUPER_ADMIN_CONF_PATHS[@]}" || true)
  SCHEDULER_CONF=$(find_first_existing_file "${SCHEDULER_CONF_PATHS[@]}" || true)
  CONTROLLER_MANAGER_CONF=$(find_first_existing_file "${CONTROLLER_MANAGER_CONF_PATHS[@]}" || true)
  PKI_DIR=$(find_first_existing_dir "${PKI_DIR_PATHS[@]}" || true)
  ETCD_DATA_DIR=$(find_first_existing_dir "${ETCD_DATA_PATHS[@]}" || true)
  CNI_CONF_DIR=$(find_first_existing_dir "${CNI_CONF_PATHS[@]}" || true)
  KUBELET_CONFIG_YAML=$(find_first_existing_file "${KUBELET_CONFIG_PATHS[@]}" || true)
  KUBELET_CONF=$(find_first_existing_file "${KUBELET_CONF_PATHS[@]}" || true)
  KUBELET_SVC=$(find_first_existing_file "${KUBELET_SVC_PATHS[@]}" || true)
fi

###############################################################################
# Manual Audit Lookup (from Kubernetes / OpenShift Security Review)
###############################################################################
get_manual_audit() {
  local id="$1"
  case "$id" in
    1.1.1) echo "stat -c %a /etc/kubernetes/manifests/kube-apiserver.yaml" ;;
    1.1.2) echo "stat -c %U:%G /etc/kubernetes/manifests/kube-apiserver.yaml" ;;
    1.1.3) echo "stat -c %a /etc/kubernetes/manifests/kube-controller-manager.yaml" ;;
    1.1.4) echo "stat -c %U:%G /etc/kubernetes/manifests/kube-controller-manager.yaml" ;;
    1.1.5) echo "stat -c %a /etc/kubernetes/manifests/kube-scheduler.yaml" ;;
    1.1.6) echo "stat -c %U:%G /etc/kubernetes/manifests/kube-scheduler.yaml" ;;
    1.1.7) echo "stat -c %a /etc/kubernetes/manifests/etcd.yaml" ;;
    1.1.8) echo "stat -c %U:%G /etc/kubernetes/manifests/etcd.yaml" ;;
    1.1.9) echo "find <path/to/cni/files> -type f -exec stat -c '%a %n' {} +" ;;
    1.1.10) echo "find <path/to/cni/files> -type f -exec stat -c '%U:%G %n' {} +" ;;
    1.1.11) echo "ps -ef | grep etcd | grep -- --data-dir && stat -c %a /var/lib/etcd" ;;
    1.1.12) echo "ps -ef | grep etcd | grep -- --data-dir && stat -c %U:%G /var/lib/etcd" ;;
    1.1.13) echo "stat -c %a /etc/kubernetes/admin.conf && stat -c %a /etc/kubernetes/super-admin.conf" ;;
    1.1.14) echo "stat -c %U:%G /etc/kubernetes/admin.conf && stat -c %U:%G /etc/kubernetes/super-admin.conf" ;;
    1.1.15) echo "stat -c %a /etc/kubernetes/scheduler.conf" ;;
    1.1.16) echo "stat -c %U:%G /etc/kubernetes/scheduler.conf" ;;
    1.1.17) echo "stat -c %a /etc/kubernetes/controller-manager.conf" ;;
    1.1.18) echo "stat -c %U:%G /etc/kubernetes/controller-manager.conf" ;;
    1.1.19) echo "find /etc/kubernetes/pki/ -type f -exec stat -c '%U:%G %n' {} +" ;;
    1.1.20) echo "find /etc/kubernetes/pki/ -name '*.crt' -exec stat -c '%a %n' {} +" ;;
    1.1.21) echo "find /etc/kubernetes/pki/ -name '*.key' -exec stat -c '%a %n' {} +" ;;
    1.2.1) echo "ps -ef | grep kube-apiserver | grep -- --anonymous-auth" ;;
    1.2.2) echo "ps -ef | grep kube-apiserver | grep -- --token-auth-file" ;;
    1.2.3) echo "ps -ef | grep kube-apiserver | grep -- --enable-admission-plugins" ;;
    1.2.4) echo "ps -ef | grep kube-apiserver | grep -- --kubelet-client-certificate" ;;
    1.2.5) echo "ps -ef | grep kube-apiserver | grep -- --kubelet-certificate-authority" ;;
    1.2.6) echo "ps -ef | grep kube-apiserver | grep -- --authorization-mode" ;;
    1.2.7) echo "ps -ef | grep kube-apiserver | grep -- --authorization-mode" ;;
    1.2.8) echo "ps -ef | grep kube-apiserver | grep -- --authorization-mode" ;;
    1.2.9) echo "ps -ef | grep kube-apiserver | grep -- --enable-admission-plugins" ;;
    1.2.10) echo "ps -ef | grep kube-apiserver | grep -- --enable-admission-plugins" ;;
    1.2.11) echo "ps -ef | grep kube-apiserver | grep -- --enable-admission-plugins" ;;
    1.2.12) echo "ps -ef | grep kube-apiserver | grep -- --disable-admission-plugins" ;;
    1.2.13) echo "ps -ef | grep kube-apiserver | grep -- --disable-admission-plugins" ;;
    1.2.14) echo "ps -ef | grep kube-apiserver | grep -- --enable-admission-plugins" ;;
    1.2.15) echo "ps -ef | grep kube-apiserver | grep -- --profiling" ;;
    1.2.16) echo "ps -ef | grep kube-apiserver | grep -- --audit-log-path" ;;
    1.2.17) echo "ps -ef | grep kube-apiserver | grep -- --audit-log-maxage" ;;
    1.2.18) echo "ps -ef | grep kube-apiserver | grep -- --audit-log-maxbackup" ;;
    1.2.19) echo "ps -ef | grep kube-apiserver | grep -- --audit-log-maxsize" ;;
    1.2.20) echo "ps -ef | grep kube-apiserver | grep -- --request-timeout" ;;
    1.2.21) echo "ps -ef | grep kube-apiserver | grep -- --service-account-lookup" ;;
    1.2.22) echo "ps -ef | grep kube-apiserver | grep -- --service-account-key-file" ;;
    1.2.23) echo "ps -ef | grep kube-apiserver | grep -- --etcd-certfile" ;;
    1.2.24) echo "ps -ef | grep kube-apiserver | grep -- --tls-cert-file" ;;
    1.2.25) echo "ps -ef | grep kube-apiserver | grep -- --client-ca-file" ;;
    1.2.26) echo "ps -ef | grep kube-apiserver | grep -- --etcd-cafile" ;;
    1.2.27) echo "ps -ef | grep kube-apiserver | grep -- --encryption-provider-config" ;;
    1.2.28) echo "ps -ef | grep kube-apiserver | grep -- --encryption-provider-config && cat <path-to-encryption-config>" ;;
    1.2.29) echo "ps -ef | grep kube-apiserver | grep -- --tls-cipher-suites" ;;
    1.2.30) echo "ps -ef | grep kube-apiserver | grep -- --service-account-extend-token-expiration" ;;
    1.3.1) echo "ps -ef | grep kube-controller-manager | grep -- --terminated-pod-gc-threshold" ;;
    1.3.2) echo "ps -ef | grep kube-controller-manager | grep -- --profiling" ;;
    1.3.3) echo "ps -ef | grep kube-controller-manager | grep -- --use-service-account-credentials" ;;
    1.3.4) echo "ps -ef | grep kube-controller-manager | grep -- --service-account-private-key-file" ;;
    1.3.5) echo "ps -ef | grep kube-controller-manager | grep -- --root-ca-file" ;;
    1.3.6) echo "ps -ef | grep kube-controller-manager | grep RotateKubeletServerCertificate" ;;
    1.3.7) echo "ps -ef | grep kube-controller-manager | grep -- --bind-address" ;;
    1.4.1) echo "ps -ef | grep kube-scheduler | grep -- --profiling" ;;
    1.4.2) echo "ps -ef | grep kube-scheduler | grep -- --bind-address" ;;
    2.1) echo "ps -ef | grep etcd | grep -- --cert-file" ;;
    2.2) echo "ps -ef | grep etcd | grep -- --client-cert-auth" ;;
    2.3) echo "ps -ef | grep etcd | grep -- --auto-tls" ;;
    2.4) echo "ps -ef | grep etcd | grep -- --peer-cert-file" ;;
    2.5) echo "ps -ef | grep etcd | grep -- --peer-client-cert-auth" ;;
    2.6) echo "ps -ef | grep etcd | grep -- --peer-auto-tls" ;;
    2.7) echo "ps -ef | grep etcd | grep -- --trusted-ca-file && ps -ef | grep kube-apiserver | grep -- --client-ca-file" ;;
    3.1.1) echo "Review user access to the cluster and ensure users are not making use of Kubernetes client certificate authentication." ;;
    3.1.2) echo "Review user access to the cluster and ensure users are not making use of service account token authentication." ;;
    3.1.3) echo "Review user access to the cluster and ensure users are not making use of bootstrap token authentication." ;;
    3.2.1) echo "ps -ef | grep kube-apiserver | grep -- --audit-policy-file && cat <audit-policy-file>" ;;
    3.2.2) echo "Review the audit policy and ensure it covers: access to Secrets/ConfigMaps/TokenReviews, modification of pods/deployments, use of pods/exec, pods/portforward, pods/proxy and services/proxy." ;;
    4.1.1) echo "stat -c %a /etc/systemd/system/kubelet.service.d/kubeadm.conf" ;;
    4.1.2) echo "stat -c %U:%G /etc/systemd/system/kubelet.service.d/kubeadm.conf" ;;
    4.1.3) echo "ps -ef | grep kube-proxy | grep -- --kubeconfig && stat -c %a <kubeconfig-path>" ;;
    4.1.4) echo "ps -ef | grep kube-proxy | grep -- --kubeconfig && stat -c %U:%G <kubeconfig-path>" ;;
    4.1.5) echo "stat -c %a /etc/kubernetes/kubelet.conf" ;;
    4.1.6) echo "stat -c %U:%G /etc/kubernetes/kubelet.conf" ;;
    4.1.7) echo "ps -ef | grep kubelet | grep -- --client-ca-file && stat -c %a <client-ca-file>" ;;
    4.1.8) echo "ps -ef | grep kubelet | grep -- --client-ca-file && stat -c %U:%G <client-ca-file>" ;;
    4.1.9) echo "stat -c %a /var/lib/kubelet/config.yaml" ;;
    4.1.10) echo "stat -c %U:%G /var/lib/kubelet/config.yaml" ;;
    4.2.1) echo "ps -ef | grep kubelet | grep -- --anonymous-auth || sudo grep 'anonymous' /var/lib/kubelet/config.yaml" ;;
    4.2.2) echo "ps -ef | grep kubelet | grep -- --authorization-mode || sudo grep 'authorization' /var/lib/kubelet/config.yaml" ;;
    4.2.3) echo "ps -ef | grep kubelet | grep -- --client-ca-file || sudo grep clientCAFile /var/lib/kubelet/config.yaml" ;;
    4.2.4) echo "ps -ef | grep kubelet | grep -- --read-only-port || sudo grep readOnlyPort /var/lib/kubelet/config.yaml" ;;
    4.2.5) echo "ps -ef | grep kubelet | grep -- --streaming-connection-idle-timeout || sudo grep streamingConnectionIdleTimeout /var/lib/kubelet/config.yaml" ;;
    4.2.6) echo "ps -ef | grep kubelet | grep -- --make-iptables-util-chains || sudo grep makeIPTablesUtilChains /var/lib/kubelet/config.yaml" ;;
    4.2.7) echo "ps -ef | grep kubelet | grep -- --hostname-override" ;;
    4.2.8) echo "ps -ef | grep kubelet | grep -- --event-qps || sudo grep eventRecordQPS /var/lib/kubelet/config.yaml" ;;
    4.2.9) echo "ps -ef | grep kubelet | grep -- --tls-cert-file || sudo grep tlsCertFile /var/lib/kubelet/config.yaml" ;;
    4.2.10) echo "ps -ef | grep kubelet | grep -- --rotate-certificates || sudo grep rotateCertificates /var/lib/kubelet/config.yaml" ;;
    4.2.11) echo "ps -ef | grep kubelet | grep RotateKubeletServerCertificate || sudo grep serverTLSBootstrap /var/lib/kubelet/config.yaml" ;;
    4.2.12) echo "ps -ef | grep kubelet | grep -- --tls-cipher-suites || sudo grep tlsCipherSuites /var/lib/kubelet/config.yaml" ;;
    4.2.13) echo "ps -ef | grep kubelet | grep -- --pod-max-pids || sudo grep PodPidsLimit /var/lib/kubelet/config.yaml" ;;
    4.2.14) echo "ps -ef | grep kubelet | grep -- --seccomp-default || sudo grep seccompDefault /var/lib/kubelet/config.yaml" ;;
    4.3.1) echo "kubectl get configmap kube-proxy -n kube-system -o yaml | grep metricsBindAddress" ;;
    5.1.1) echo "kubectl get clusterrolebindings -o=custom-columns=NAME:.metadata.name,ROLE:.roleRef.name,SUBJECT:.subjects[*].name" ;;
    5.1.2) echo "Review the users who have get, list, or watch access to secrets objects in the Kubernetes API." ;;
    5.1.3) echo "kubectl get roles --all-namespaces -o yaml && kubectl get clusterroles -o yaml" ;;
    5.1.4) echo "Review the users who have create access to pod objects in the Kubernetes API." ;;
    5.1.5) echo "kubectl get serviceaccounts --all-namespaces -o yaml | grep automountServiceAccountToken" ;;
    5.1.6) echo "Review pod and service account objects and ensure automountServiceAccountToken: false is set where not needed." ;;
    5.1.7) echo "Review all credentials with access to the cluster and ensure the group system:masters is not used." ;;
    5.1.8) echo "Review the users who have impersonate, bind, or escalate privileges." ;;
    5.1.9) echo "Review the users who have create access to PersistentVolume objects." ;;
    5.1.10) echo "Review the users who have access to the proxy sub-resource of node objects." ;;
    5.1.11) echo "Review the users who have access to update the approval sub-resource of CertificateSigningRequests." ;;
    5.1.12) echo "Review the users who have access to validatingwebhookconfigurations or mutatingwebhookconfigurations." ;;
    5.1.13) echo "Review the users who have access to create the token sub-resource of serviceaccount objects." ;;
    5.2.1) echo "Review workloads and verify Pod Security Admission or external admission control is in place." ;;
    5.2.2) echo "kubectl get pods -A -o=jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext}\n{end}'" ;;
    5.2.3) echo "kubectl get pods -A -o=jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostPID}\n{end}'" ;;
    5.2.4) echo "kubectl get pods -A -o=jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostIPC}\n{end}'" ;;
    5.2.5) echo "kubectl get pods -A -o=jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostNetwork}\n{end}'" ;;
    5.2.6) echo "kubectl get pods -A -o=jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext}\n{end}' && verify allowPrivilegeEscalation is not set to true" ;;
    5.2.7) echo "Review policies for each namespace ensuring MustRunAsNonRoot or MustRunAs with UID range not including 0." ;;
    5.2.8) echo "Review policies for each namespace ensuring at least one disallows containers with NET_RAW capability." ;;
    5.2.9) echo "Review policies for each namespace ensuring at least one requires all capabilities to be dropped." ;;
    5.2.10) echo "Review policies for each namespace ensuring hostProcess containers are disallowed." ;;
    5.2.11) echo "Review policies for each namespace ensuring hostPath volumes are disallowed." ;;
    5.2.12) echo "Review policies for each namespace ensuring hostPort sections are disallowed." ;;
    5.3.1) echo "Review the CNI plugin documentation and confirm it supports Ingress and Egress network policies." ;;
    5.3.2) echo "kubectl get networkpolicy --all-namespaces" ;;
    5.4.1) echo "kubectl get all -o jsonpath='{range .items[?(@..secretKeyRef)]} {.kind} {.metadata.name} {\"\n\"}{end}' -A" ;;
    5.4.2) echo "Review your secrets management implementation." ;;
    5.5.1) echo "Review pod definitions and verify image provenance is configured as appropriate." ;;
    5.6.1) echo "kubectl get namespaces" ;;
    5.6.2) echo "Review pod definitions and verify securityContext: seccompProfile: type: RuntimeDefault is set." ;;
    5.6.3) echo "Review pod definitions and verify security contexts are defined as appropriate." ;;
    5.6.4) echo "kubectl get \$(kubectl api-resources --verbs=list --namespaced=true -o name | paste -sd, -) --ignore-not-found -n default" ;;
    *) echo "" ;;
  esac
}

###############################################################################
# Remediation Lookup (from Kubernetes / OpenShift Security Review)
###############################################################################
get_remediation() {
  local id="$1"
  case "$id" in
    1.1.1) echo "Run the below command on the Control Plane node. For example, chmod 600 /etc/kubernetes/manifests/kube-apiserver.yaml" ;;
    1.1.2) echo "Run the below command on the Control Plane node. For example, chown root:root /etc/kubernetes/manifests/kube-apiserver.yaml" ;;
    1.1.3) echo "Run the below command on the Control Plane node. For example, chmod 600 /etc/kubernetes/manifests/kube-controller-manager.yaml" ;;
    1.1.4) echo "Run the below command on the Control Plane node. For example, chown root:root /etc/kubernetes/manifests/kube-controller-manager.yaml" ;;
    1.1.5) echo "Run the below command on the Control Plane node. For example, chmod 600 /etc/kubernetes/manifests/kube-scheduler.yaml" ;;
    1.1.6) echo "Run the below command on the Control Plane node. For example, chown root:root /etc/kubernetes/manifests/kube-scheduler.yaml" ;;
    1.1.7) echo "Run the below command on the Control Plane node. For example, chmod 600 /etc/kubernetes/manifests/etcd.yaml" ;;
    1.1.8) echo "Run the below command on the Control Plane node. For example, chown root:root /etc/kubernetes/manifests/etcd.yaml" ;;
    1.1.9) echo "Run the below command on the Control Plane node. For example, chmod 600 <path/to/cni/files>" ;;
    1.1.10) echo "Run the below command on the Control Plane node. For example, chown root:root <path/to/cni/files>" ;;
    1.1.11) echo "On the etcd server node, get the etcd data directory from: ps -ef | grep etcd. Then run: chmod 700 /var/lib/etcd" ;;
    1.1.12) echo "On the etcd server node, get the etcd data directory from: ps -ef | grep etcd. Then run: chown etcd:etcd /var/lib/etcd" ;;
    1.1.13) echo "Run on the Control Plane node: chmod 600 /etc/kubernetes/admin.conf. On K8s 1.29+ also: chmod 600 /etc/kubernetes/super-admin.conf" ;;
    1.1.14) echo "Run on the Control Plane node: chown root:root /etc/kubernetes/admin.conf. On K8s 1.29+ also: chown root:root /etc/kubernetes/super-admin.conf" ;;
    1.1.15) echo "Run on the Control Plane node: chmod 600 /etc/kubernetes/scheduler.conf" ;;
    1.1.16) echo "Run on the Control Plane node: chown root:root /etc/kubernetes/scheduler.conf" ;;
    1.1.17) echo "Run on the Control Plane node: chmod 600 /etc/kubernetes/controller-manager.conf" ;;
    1.1.18) echo "Run on the Control Plane node: chown root:root /etc/kubernetes/controller-manager.conf" ;;
    1.1.19) echo "Run on the Control Plane node: chown -R root:root /etc/kubernetes/pki/" ;;
    1.1.20) echo "Run the below command (based on the file location on your system) on the Control Plane node. For example, chmod -R 644 /etc/kubernetes/pki/*.crt" ;;
    1.1.21) echo "Run the below command (based on the file location on your system) on the Control Plane node. For example, chmod -R 600 /etc/kubernetes/pki/*.key" ;;
    1.2.1) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --anonymous-auth=false" ;;
    1.2.2) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and remove the --token-auth-file=<filename> parameter." ;;
    1.2.3) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --enable-admission-plugins=...,DenyServiceExternalIPs,..." ;;
    1.2.4) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --kubelet-client-certificate=<path/to/client-cert> --kubelet-client-key=<path/to/client-key>" ;;
    1.2.5) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --kubelet-certificate-authority=<path/to/ca-file>" ;;
    1.2.6) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --authorization-mode to a value other than AlwaysAllow (e.g. RBAC)." ;;
    1.2.7) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --authorization-mode=Node,RBAC" ;;
    1.2.8) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --authorization-mode to include RBAC (e.g. --authorization-mode=Node,RBAC)" ;;
    1.2.9) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --enable-admission-plugins=...,EventRateLimit,... --admission-control-config-file=<path/to/config>" ;;
    1.2.10) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and ensure --enable-admission-plugins does not include AlwaysAdmit." ;;
    1.2.11) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --enable-admission-plugins=...,AlwaysPullImages,..." ;;
    1.2.12) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and ensure --disable-admission-plugins does not include ServiceAccount." ;;
    1.2.13) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and ensure --disable-admission-plugins does not include NamespaceLifecycle." ;;
    1.2.14) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --enable-admission-plugins=...,NodeRestriction,..." ;;
    1.2.15) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --profiling=false" ;;
    1.2.16) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --audit-log-path=/var/log/apiserver/audit.log" ;;
    1.2.17) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --audit-log-maxage=30" ;;
    1.2.18) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --audit-log-maxbackup=10" ;;
    1.2.19) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --audit-log-maxsize=100" ;;
    1.2.20) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --request-timeout=300s (or appropriate value)" ;;
    1.2.21) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --service-account-lookup=true" ;;
    1.2.22) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --service-account-key-file=<path/to/public-key>" ;;
    1.2.23) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --etcd-certfile=<path/to/cert> --etcd-keyfile=<path/to/key>" ;;
    1.2.24) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --tls-cert-file=<path/to/tls-cert> --tls-private-key-file=<path/to/tls-key>" ;;
    1.2.25) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --client-ca-file=<path/to/client-ca-file>" ;;
    1.2.26) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --etcd-cafile=<path/to/ca-file>" ;;
    1.2.27) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --encryption-provider-config=<path/to/EncryptionConfig>" ;;
    1.2.28) echo "Configure EncryptionConfig file and choose aescbc, kms, or secretbox as the encryption provider." ;;
    1.2.29) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --tls-cipher-suites to use strong ciphers (e.g. TLS_AES_128_GCM_SHA256,TLS_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,...)" ;;
    1.2.30) echo "Edit /etc/kubernetes/manifests/kube-apiserver.yaml and set --service-account-extend-token-expiration=false" ;;
    1.3.1) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --terminated-pod-gc-threshold=10 (or appropriate value)" ;;
    1.3.2) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --profiling=false" ;;
    1.3.3) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --use-service-account-credentials=true" ;;
    1.3.4) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --service-account-private-key-file=<path/to/private-key>" ;;
    1.3.5) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --root-ca-file=<path/to/ca-bundle>" ;;
    1.3.6) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and set --feature-gates=RotateKubeletServerCertificate=true" ;;
    1.3.7) echo "Edit /etc/kubernetes/manifests/kube-controller-manager.yaml and ensure --bind-address is set to 127.0.0.1" ;;
    1.4.1) echo "Edit /etc/kubernetes/manifests/kube-scheduler.yaml and set --profiling=false" ;;
    1.4.2) echo "Edit /etc/kubernetes/manifests/kube-scheduler.yaml and ensure --bind-address is set to 127.0.0.1" ;;
    2.1) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --cert-file and --key-file parameters." ;;
    2.2) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --client-cert-auth=true" ;;
    2.3) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --auto-tls=false" ;;
    2.4) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --peer-cert-file and --peer-key-file parameters." ;;
    2.5) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --peer-client-cert-auth=true" ;;
    2.6) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and set --peer-auto-tls=false" ;;
    2.7) echo "Edit the etcd pod specification file /etc/kubernetes/manifests/etcd.yaml and configure a unique Certificate Authority for etcd." ;;
    3.1.1) echo "Follow the Kubernetes documentation and set the desired audit policy in the audit policy file. Then start the API server with auditing enabled." ;;
    3.1.2) echo "Consider modification of the audit policy to include these items, at a minimum." ;;
    3.1.3) echo "Alternative mechanisms provided by Kubernetes such as the use of OIDC should be implemented in place of bootstrap tokens." ;;
    3.2.1) echo "Create an audit policy file for your cluster." ;;
    3.2.2) echo "Consider modification of the audit policy in use on the cluster to include these items, at a minimum." ;;
    4.1.1) echo "Run on each worker node: chmod 600 /etc/systemd/system/kubelet.service.d/kubeadm.conf" ;;
    4.1.2) echo "Run on each worker node: chown root:root /etc/systemd/system/kubelet.service.d/kubeadm.conf" ;;
    4.1.3) echo "Run on each worker node: chmod 600 <proxy kubeconfig file>" ;;
    4.1.4) echo "Run on each worker node: chown root:root <proxy kubeconfig file>" ;;
    4.1.5) echo "Run on each worker node: chmod 600 /etc/kubernetes/kubelet.conf" ;;
    4.1.6) echo "Run on each worker node: chown root:root /etc/kubernetes/kubelet.conf" ;;
    4.1.7) echo "Run: chmod 644 <client-ca-file-path>" ;;
    4.1.8) echo "Run: chown root:root <client-ca-file-path>" ;;
    4.1.9) echo "Run: chmod 600 /var/lib/kubelet/config.yaml (or the kubelet config file location on your system)" ;;
    4.1.10) echo "Run: chown root:root /var/lib/kubelet/config.yaml (or the kubelet config file location on your system)" ;;
    4.2.1) echo "Set authentication.anonymous.enabled to false in kubelet config, or set --anonymous-auth=false. Restart kubelet." ;;
    4.2.2) echo "Set authorization.mode to Webhook in kubelet config, or set --authorization-mode=Webhook. Restart kubelet." ;;
    4.2.3) echo "Set authentication.x509.clientCAFile in kubelet config, or set --client-ca-file=<path/to/client-ca-file>. Restart kubelet." ;;
    4.2.4) echo "Set readOnlyPort to 0 in kubelet config, or set --read-only-port=0. Restart kubelet." ;;
    4.2.5) echo "Set streamingConnectionIdleTimeout to a non-zero value in kubelet config, or set --streaming-connection-idle-timeout=5m. Restart kubelet." ;;
    4.2.6) echo "Set makeIPTablesUtilChains to true in kubelet config, or remove --make-iptables-util-chains argument. Restart kubelet." ;;
    4.2.7) echo "Remove the --hostname-override argument from kubelet service file. Restart kubelet." ;;
    4.2.8) echo "Set eventRecordQPS to an appropriate level in kubelet config. Restart kubelet." ;;
    4.2.9) echo "Set tlsCertFile and tlsPrivateKeyFile in kubelet config, or set --tls-cert-file and --tls-private-key-file. Restart kubelet." ;;
    4.2.10) echo "Set rotateCertificates to true in kubelet config, or set --rotate-certificates=true. Restart kubelet." ;;
    4.2.11) echo "Set --feature-gates=RotateKubeletServerCertificate=true in kubelet service file. Restart kubelet." ;;
    4.2.12) echo "Set tlsCipherSuites in kubelet config to use strong ciphers (e.g. TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384). Restart kubelet." ;;
    4.2.13) echo "Set PodPidsLimit via --pod-max-pids or in kubelet configuration file." ;;
    4.2.14) echo "Set seccompDefault via --seccomp-default or in kubelet configuration file." ;;
    4.3.1) echo "Modify or remove any values which bind the kube-proxy metrics service to a non-localhost address." ;;
    5.1.1) echo "Identify all clusterrolebindings to cluster-admin. Where possible, bind users to lower-privileged roles. kubectl delete clusterrolebinding [name]" ;;
    5.1.2) echo "Where possible, restrict access to secret objects by removing get, list, and watch permissions." ;;
    5.1.3) echo "Where possible, replace any use of wildcards in ClusterRoles and Roles with specific objects or actions." ;;
    5.1.4) echo "Where possible, remove create access to pod objects in the cluster." ;;
    5.1.5) echo "Create explicit service accounts for workloads. Set automountServiceAccountToken: false on each default service account." ;;
    5.1.6) echo "Modify pods and service accounts that do not need to mount service account tokens to disable it." ;;
    5.1.7) echo "Remove the system:masters group from all users in the cluster." ;;
    5.1.8) echo "Where possible, remove the impersonate, bind, and escalate rights from subjects." ;;
    5.1.9) echo "Where possible, remove create access to PersistentVolume objects in the cluster." ;;
    5.1.10) echo "Where possible, remove access to the proxy sub-resource of node objects." ;;
    5.1.11) echo "Where possible, remove access to the approval sub-resource of CertificateSigningRequests objects." ;;
    5.1.12) echo "Where possible, remove access to validatingwebhookconfigurations or mutatingwebhookconfigurations objects." ;;
    5.1.13) echo "Where possible, remove access to the token sub-resource of serviceaccount objects." ;;
    5.2.1) echo "Ensure Pod Security Admission or an external policy control system is in place for every namespace with user workloads." ;;
    5.2.2) echo "Add policies to each namespace in the cluster which has user workloads to restrict the admission of privileged containers." ;;
    5.2.3) echo "Configure the Admission Controller to restrict the admission of hostPID containers." ;;
    5.2.4) echo "Add policies to restrict the admission of hostIPC containers." ;;
    5.2.5) echo "Add policies to restrict the admission of hostNetwork containers." ;;
    5.2.6) echo "Add policies to restrict containers with allowPrivilegeEscalation: true." ;;
    5.2.7) echo "Create a policy ensuring MustRunAsNonRoot or MustRunAs (with UID range not including 0) is set." ;;
    5.2.8) echo "Add policies to restrict the admission of containers with the NET_RAW capability." ;;
    5.2.9) echo "Review capabilities in applications. Where possible, add a policy forbidding containers that do not drop all capabilities." ;;
    5.2.10) echo "Add policies to restrict the admission of hostProcess containers." ;;
    5.2.11) echo "Add policies to restrict the admission of containers which use hostPath volumes." ;;
    5.2.12) echo "Add policies to restrict the admission of containers which use hostPort sections." ;;
    5.3.1) echo "If the CNI plugin does not support network policies, consider using a different plugin or alternate mechanism for restricting traffic." ;;
    5.3.2) echo "Follow the documentation and create NetworkPolicy objects as you need them." ;;
    5.4.1) echo "If possible, rewrite application code to read secrets from mounted secret files, rather than from environment variables." ;;
    5.4.2) echo "Refer to the secrets management options offered by your cloud provider or a third-party secrets management solution." ;;
    5.5.1) echo "Follow the Kubernetes documentation and setup image provenance using the ImagePolicyWebhook admission controller." ;;
    5.6.1) echo "Follow the documentation and create namespaces for objects in your deployment as you need them." ;;
    5.6.2) echo "Use security context to enable seccomp: securityContext: seccompProfile: type: RuntimeDefault" ;;
    5.6.3) echo "Follow the Kubernetes documentation and apply security contexts to your pods." ;;
    5.6.4) echo "Create namespaces to segregate Kubernetes resources and ensure all new resources are created in a specific namespace." ;;
    *) echo "" ;;
  esac
}

###############################################################################
# Helper Functions
###############################################################################
info() {
  if ! $JSON_OUTPUT; then
    printf "${BLUE}[INFO]${NC} %s\n" "$*"
  fi
}

header() {
  if ! $JSON_OUTPUT; then
    printf "\n${BOLD}${CYAN}%s${NC}\n" "$*"
    printf '%*s\n' "${#1}" '' | tr ' ' '-'
  fi
}

result_pass() {
  local id="$1" desc="$2"
  ((TOTAL++)) || true
  ((PASS++)) || true
  ALL_RESULTS+=("${id}${_D}PASS${_D}${desc}${_D}${_D}${_D}$(get_remediation "$id")")
  if $JSON_OUTPUT; then
    JSON_RESULTS+="{\"id\":\"$id\",\"desc\":\"$desc\",\"result\":\"PASS\"},"
  else
    printf "${GREEN}[PASS]${NC} %s %s\n" "$id" "$desc"
  fi
}

result_fail() {
  local id="$1" desc="$2" detail="${3:-}" audit_output="${4:-$_AUDIT_CONTEXT}"
  ((TOTAL++)) || true
  ((FAIL++)) || true
  ALL_RESULTS+=("${id}${_D}FAIL${_D}${desc}${_D}${detail}${_D}${audit_output}${_D}$(get_remediation "$id")")
  if $JSON_OUTPUT; then
    # Escape newlines/quotes for JSON
    local json_output
    json_output=$(echo "$audit_output" | sed ':a;N;$!ba;s/\n/\\n/g;s/"/\\"/g')
    JSON_RESULTS+="{\"id\":\"$id\",\"desc\":\"$desc\",\"result\":\"FAIL\",\"detail\":\"$detail\",\"audit_output\":\"$json_output\"},"
  else
    printf "${RED}[FAIL]${NC} %s %s\n" "$id" "$desc"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    if [[ -n "$audit_output" ]]; then
      printf "       ${BOLD}Audit Output:${NC}\n"
      while IFS= read -r line; do
        printf "         %s\n" "$line"
      done <<< "$audit_output"
    fi
  fi
}

result_warn() {
  local id="$1" desc="$2" detail="${3:-}"
  local manual_audit
  manual_audit=$(get_manual_audit "$id")
  ((TOTAL++)) || true
  ((WARN++)) || true
  ALL_RESULTS+=("${id}${_D}WARN${_D}${desc}${_D}${detail}${_D}${manual_audit}${_D}$(get_remediation "$id")")
  if $JSON_OUTPUT; then
    local json_ma
    json_ma=$(echo "$manual_audit" | sed ':a;N;$!ba;s/\n/\\n/g;s/"/\\"/g')
    JSON_RESULTS+="{\"id\":\"$id\",\"desc\":\"$desc\",\"result\":\"WARN\",\"detail\":\"$detail\",\"manual_audit\":\"$json_ma\"},"
  else
    printf "${YELLOW}[WARN]${NC} %s %s\n" "$id" "$desc"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    if [[ -n "$manual_audit" ]]; then
      printf "       ${BOLD}Manual Audit:${NC}\n"
      printf "         %s\n" "$manual_audit"
    fi
  fi
}

result_info() {
  local id="$1" desc="$2" detail="${3:-}"
  local manual_audit
  manual_audit=$(get_manual_audit "$id")
  ((TOTAL++)) || true
  ((INFO++)) || true
  ALL_RESULTS+=("${id}${_D}INFO${_D}${desc}${_D}${detail}${_D}${manual_audit}${_D}$(get_remediation "$id")")
  if $JSON_OUTPUT; then
    local json_ma
    json_ma=$(echo "$manual_audit" | sed ':a;N;$!ba;s/\n/\\n/g;s/"/\\"/g')
    JSON_RESULTS+="{\"id\":\"$id\",\"desc\":\"$desc\",\"result\":\"INFO\",\"detail\":\"$detail\",\"manual_audit\":\"$json_ma\"},"
  else
    printf "${BLUE}[INFO]${NC} %s %s\n" "$id" "$desc"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    if [[ -n "$manual_audit" ]]; then
      printf "       ${BOLD}Manual Audit:${NC}\n"
      printf "         %s\n" "$manual_audit"
    fi
  fi
}

result_skip() {
  local id="$1" desc="$2" detail="${3:-}"
  local manual_audit
  manual_audit=$(get_manual_audit "$id")
  ((TOTAL++)) || true
  ((SKIP++)) || true
  ALL_RESULTS+=("${id}${_D}SKIP${_D}${desc}${_D}${detail}${_D}${manual_audit}${_D}$(get_remediation "$id")")
  if $JSON_OUTPUT; then
    local json_ma
    json_ma=$(echo "$manual_audit" | sed ':a;N;$!ba;s/\n/\\n/g;s/"/\\"/g')
    JSON_RESULTS+="{\"id\":\"$id\",\"desc\":\"$desc\",\"result\":\"SKIP\",\"detail\":\"$detail\",\"manual_audit\":\"$json_ma\"},"
  else
    printf "${YELLOW}[SKIP]${NC} %s %s\n" "$id" "$desc"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    if [[ -n "$manual_audit" ]]; then
      printf "       ${BOLD}Manual Audit:${NC}\n"
      printf "         %s\n" "$manual_audit"
    fi
  fi
}

# Check file permissions: check_file_perms <id> <desc> <file> <max_perms>
# max_perms: e.g. 600 means perms must be <= 600 (no group/other write etc.)
check_file_perms() {
  local id="$1" desc="$2" file="$3" max_perms="$4"
  if ! _test_f "$file"; then
    result_skip "$id" "$desc" "File not found: $file"
    return
  fi
  local perms
  perms=$(_stat "-c %a '$file'" 2>/dev/null)
  local stat_full
  stat_full=$(_stat "'$file'" 2>/dev/null)
  # Check each octet: owner, group, other must be <= corresponding max digit
  local o_max=${max_perms:0:1} g_max=${max_perms:1:1} w_max=${max_perms:2:1}
  local o_cur=${perms:0:1} g_cur=${perms:1:1} w_cur=${perms:2:1}
  if (( o_cur <= o_max && g_cur <= g_max && w_cur <= w_max )); then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "Permissions are $perms, expected $max_perms or more restrictive" "$ stat $file
$stat_full"
  fi
}

# Check file ownership: check_file_owner <id> <desc> <file> <expected_owner>
check_file_owner() {
  local id="$1" desc="$2" file="$3" expected="$4"
  if ! _test_f "$file" && ! _test_d "$file"; then
    result_skip "$id" "$desc" "Path not found: $file"
    return
  fi
  local owner
  owner=$(_stat "-c %U:%G '$file'" 2>/dev/null)
  local stat_full
  stat_full=$(_stat "'$file'" 2>/dev/null)
  if [[ "$owner" == "$expected" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "Ownership is $owner, expected $expected" "$ stat $file
$stat_full"
  fi
}

# Check directory permissions
check_dir_perms() {
  local id="$1" desc="$2" dir="$3" max_perms="$4"
  if ! _test_d "$dir"; then
    result_skip "$id" "$desc" "Directory not found: $dir"
    return
  fi
  local perms
  perms=$(_stat "-c %a '$dir'" 2>/dev/null)
  local stat_full
  stat_full=$(_stat "'$dir'" 2>/dev/null)
  local o_max=${max_perms:0:1} g_max=${max_perms:1:1} w_max=${max_perms:2:1}
  local o_cur=${perms:0:1} g_cur=${perms:1:1} w_cur=${perms:2:1}
  if (( o_cur <= o_max && g_cur <= g_max && w_cur <= w_max )); then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "Permissions are $perms, expected $max_perms or more restrictive" "$ stat $dir
$stat_full"
  fi
}

# Get process arguments for a given process
get_process_args() {
  local proc_name="$1"
  _rcmd "ps -ef 2>/dev/null | grep -v grep | grep '$proc_name' | head -1" || true
}

# Check if a specific argument is set in a process
get_argument_value() {
  local proc_line="$1" arg="$2"
  echo "$proc_line" | grep -oP -- "${arg}=\K[^ ]+" 2>/dev/null || true
}

# Check if an argument exists in process
has_argument() {
  local proc_line="$1" arg="$2"
  echo "$proc_line" | grep -q -- "$arg" 2>/dev/null
}

# Format process args for audit output display (one arg per line)
format_proc_args() {
  local proc_line="$1" proc_name="$2"
  echo "$ ps -ef | grep $proc_name"
  # Print the process line with each --arg on its own line for readability
  echo "$proc_line" | sed 's/ --/\n  --/g'
}

# Try to get a value from the kubelet config yaml
get_kubelet_config_value() {
  local key="$1"
  if _test_f "$KUBELET_CONFIG_YAML"; then
    _rcmd "grep -i '$key' '$KUBELET_CONFIG_YAML' 2>/dev/null | head -1 | awk '{print \$NF}'" || true
  fi
}

should_run_section() {
  local section_num="$1"
  if [[ -n "$FILTER_SECTION" ]] && [[ "$section_num" != "$FILTER_SECTION" ]]; then
    return 1
  fi
  return 0
}

###############################################################################
# 1 - Control Plane Components
###############################################################################

run_1_1() {
  header "1.1 - Control Plane Node Configuration Files"

  # 1.1.1
  check_file_perms "1.1.1" \
    "Ensure that the API server pod specification file permissions are set to 600 or more restrictive (Automated)" \
    "$APISERVER_POD_SPEC" "600"

  # 1.1.2
  check_file_owner "1.1.2" \
    "Ensure that the API server pod specification file ownership is set to root:root (Automated)" \
    "$APISERVER_POD_SPEC" "root:root"

  # 1.1.3
  check_file_perms "1.1.3" \
    "Ensure that the controller manager pod specification file permissions are set to 600 or more restrictive (Automated)" \
    "$CONTROLLER_MANAGER_POD_SPEC" "600"

  # 1.1.4
  check_file_owner "1.1.4" \
    "Ensure that the controller manager pod specification file ownership is set to root:root (Automated)" \
    "$CONTROLLER_MANAGER_POD_SPEC" "root:root"

  # 1.1.5
  check_file_perms "1.1.5" \
    "Ensure that the scheduler pod specification file permissions are set to 600 or more restrictive (Automated)" \
    "$SCHEDULER_POD_SPEC" "600"

  # 1.1.6
  check_file_owner "1.1.6" \
    "Ensure that the scheduler pod specification file ownership is set to root:root (Automated)" \
    "$SCHEDULER_POD_SPEC" "root:root"

  # 1.1.7
  check_file_perms "1.1.7" \
    "Ensure that the etcd pod specification file permissions are set to 600 or more restrictive (Automated)" \
    "$ETCD_POD_SPEC" "600"

  # 1.1.8
  check_file_owner "1.1.8" \
    "Ensure that the etcd pod specification file ownership is set to root:root (Automated)" \
    "$ETCD_POD_SPEC" "root:root"

  # 1.1.9 (Manual)
  local id="1.1.9"
  local desc="Ensure that the Container Network Interface file permissions are set to 600 or more restrictive (Manual)"
  if _test_d "$CNI_CONF_DIR"; then
    local bad_files=""
    local cni_files
    cni_files=$(_find "$CNI_CONF_DIR" -type f 2>/dev/null || true)
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local perms
      perms=$(_stat "-c %a '$f'")
      local o=${perms:0:1} g=${perms:1:1} w=${perms:2:1}
      if (( o > 6 || g > 0 || w > 0 )); then
        bad_files+="$f($perms) "
      fi
    done <<< "$cni_files"
    if [[ -z "$bad_files" ]]; then
      result_pass "$id" "$desc"
    else
      local cni_stat_output
      cni_stat_output=$(_find "$CNI_CONF_DIR" -type f -exec stat {} \\\; 2>/dev/null || true)
      result_fail "$id" "$desc" "Files with excessive permissions: $bad_files" "$ find $CNI_CONF_DIR -type f -exec stat {} \\;
$cni_stat_output"
    fi
  else
    result_skip "$id" "$desc" "CNI config dir not found: $CNI_CONF_DIR"
  fi

  # 1.1.10 (Manual)
  id="1.1.10"
  desc="Ensure that the Container Network Interface file ownership is set to root:root (Manual)"
  if _test_d "$CNI_CONF_DIR"; then
    local bad_owner=""
    local cni_files
    cni_files=$(_find "$CNI_CONF_DIR" -type f 2>/dev/null || true)
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local owner
      owner=$(_stat "-c %U:%G '$f'")
      if [[ "$owner" != "root:root" ]]; then
        bad_owner+="$f($owner) "
      fi
    done <<< "$cni_files"
    if [[ -z "$bad_owner" ]]; then
      result_pass "$id" "$desc"
    else
      local cni_owner_output
      cni_owner_output=$(_find "$CNI_CONF_DIR" -type f -exec stat -c "'%n %U:%G'" {} \\\; 2>/dev/null || true)
      result_fail "$id" "$desc" "Files with wrong ownership: $bad_owner" "$ find $CNI_CONF_DIR -type f -exec stat -c '%n %U:%G' {} \\;
$cni_owner_output"
    fi
  else
    result_skip "$id" "$desc" "CNI config dir not found: $CNI_CONF_DIR"
  fi

  # 1.1.11
  local etcd_data_dir="$ETCD_DATA_DIR"
  # Try to detect from process
  local etcd_proc
  etcd_proc=$(get_process_args "etcd" || true)
  if [[ -n "$etcd_proc" ]]; then
    local detected_dir
    detected_dir=$(echo "$etcd_proc" | grep -oP '\-\-data-dir=\K[^ ]+' || true)
    [[ -n "$detected_dir" ]] && etcd_data_dir="$detected_dir"
  fi
  check_dir_perms "1.1.11" \
    "Ensure that the etcd data directory permissions are set to 700 or more restrictive (Automated)" \
    "$etcd_data_dir" "700"

  # 1.1.12
  id="1.1.12"
  desc="Ensure that the etcd data directory ownership is set to etcd:etcd (Automated)"
  if _test_d "$etcd_data_dir"; then
    local owner
    owner=$(_stat "-c %U:%G '$etcd_data_dir'")
    if [[ "$owner" == "etcd:etcd" ]]; then
      result_pass "$id" "$desc"
    else
      local stat_full
      stat_full=$(_stat "'$etcd_data_dir'" 2>/dev/null || true)
      result_fail "$id" "$desc" "Ownership is $owner, expected etcd:etcd" "$ stat $etcd_data_dir
$stat_full"
    fi
  else
    result_skip "$id" "$desc" "etcd data dir not found: $etcd_data_dir"
  fi

  # 1.1.13
  check_file_perms "1.1.13" \
    "Ensure that the default administrative credential file permissions are set to 600 (Automated)" \
    "$ADMIN_CONF" "600"
  # Also check super-admin.conf if it exists
  if _test_f "$SUPER_ADMIN_CONF"; then
    check_file_perms "1.1.13b" \
      "Ensure that the super-admin.conf file permissions are set to 600 (Automated)" \
      "$SUPER_ADMIN_CONF" "600"
  fi

  # 1.1.14
  check_file_owner "1.1.14" \
    "Ensure that the default administrative credential file ownership is set to root:root (Automated)" \
    "$ADMIN_CONF" "root:root"

  # 1.1.15
  check_file_perms "1.1.15" \
    "Ensure that the scheduler.conf file permissions are set to 600 or more restrictive (Automated)" \
    "$SCHEDULER_CONF" "600"

  # 1.1.16
  check_file_owner "1.1.16" \
    "Ensure that the scheduler.conf file ownership is set to root:root (Automated)" \
    "$SCHEDULER_CONF" "root:root"

  # 1.1.17
  check_file_perms "1.1.17" \
    "Ensure that the controller-manager.conf file permissions are set to 600 or more restrictive (Automated)" \
    "$CONTROLLER_MANAGER_CONF" "600"

  # 1.1.18
  check_file_owner "1.1.18" \
    "Ensure that the controller-manager.conf file ownership is set to root:root (Automated)" \
    "$CONTROLLER_MANAGER_CONF" "root:root"

  # 1.1.19
  id="1.1.19"
  desc="Ensure that the Kubernetes PKI directory and file ownership is set to root:root (Automated)"
  if _test_d "$PKI_DIR"; then
    local bad_pki_owner=""
    local pki_files
    pki_files=$(_find "$PKI_DIR" 2>/dev/null || true)
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local owner
      owner=$(_stat "-c %U:%G '$f'")
      if [[ "$owner" != "root:root" ]]; then
        bad_pki_owner+="$f($owner) "
      fi
    done <<< "$pki_files"
    if [[ -z "$bad_pki_owner" ]]; then
      result_pass "$id" "$desc"
    else
      local pki_owner_output
      pki_owner_output=$(_find "$PKI_DIR" -exec stat -c "'%n %U:%G'" {} \\\; 2>/dev/null || true)
      result_fail "$id" "$desc" "Files/dirs with wrong ownership: $bad_pki_owner" "$ find $PKI_DIR -exec stat -c '%n %U:%G' {} \\;
$pki_owner_output"
    fi
  else
    result_skip "$id" "$desc" "PKI directory not found: $PKI_DIR"
  fi

  # 1.1.20 (Manual)
  id="1.1.20"
  desc="Ensure that the Kubernetes PKI certificate file permissions are set to 644 or more restrictive (Manual)"
  if _test_d "$PKI_DIR"; then
    local bad_cert_perms=""
    local cert_files
    cert_files=$(_rcmd "{ find '$PKI_DIR' -name '*.crt' 2>/dev/null; find '$PKI_DIR' -name '*.pem' -not -name '*key*' 2>/dev/null; }" || true)
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local perms
      perms=$(_stat "-c %a '$f'")
      local o=${perms:0:1} g=${perms:1:1} w=${perms:2:1}
      if (( o > 6 || g > 4 || w > 4 )); then
        bad_cert_perms+="$f($perms) "
      fi
    done <<< "$cert_files"
    if [[ -z "$bad_cert_perms" ]]; then
      result_pass "$id" "$desc"
    else
      local pki_cert_output
      pki_cert_output=$(_rcmd "find '$PKI_DIR' \( -name '*.crt' -o \( -name '*.pem' -not -name '*key*' \) \) -exec stat -c '%a %n' {} \;" 2>/dev/null || true)
      result_fail "$id" "$desc" "Cert files with excessive permissions: $bad_cert_perms" "$ find $PKI_DIR -name '*.crt' -o -name '*.pem' -exec stat -c '%a %n' {} \\;
$pki_cert_output"
    fi
  else
    result_skip "$id" "$desc" "PKI directory not found: $PKI_DIR"
  fi

  # 1.1.21 (Manual)
  id="1.1.21"
  desc="Ensure that the Kubernetes PKI key file permissions are set to 600 (Manual)"
  if _test_d "$PKI_DIR"; then
    local bad_key_perms=""
    local key_files
    key_files=$(_find "$PKI_DIR" -name "'*.key'" 2>/dev/null || true)
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local perms
      perms=$(_stat "-c %a '$f'")
      local o=${perms:0:1} g=${perms:1:1} w=${perms:2:1}
      if (( o > 6 || g > 0 || w > 0 )); then
        bad_key_perms+="$f($perms) "
      fi
    done <<< "$key_files"
    if [[ -z "$bad_key_perms" ]]; then
      result_pass "$id" "$desc"
    else
      local pki_key_output
      pki_key_output=$(_find "$PKI_DIR" -name "'*.key'" -exec stat -c "'%a %n'" {} \\\; 2>/dev/null || true)
      result_fail "$id" "$desc" "Key files with excessive permissions: $bad_key_perms" "$ find $PKI_DIR -name '*.key' -exec stat -c '%a %n' {} \\;
$pki_key_output"
    fi
  else
    result_skip "$id" "$desc" "PKI directory not found: $PKI_DIR"
  fi
}

run_1_2() {
  header "1.2 - API Server"

  local apiserver_proc
  apiserver_proc=$(get_process_args "kube-apiserver" || true)

  if [[ -z "$apiserver_proc" ]]; then
    info "kube-apiserver process not found. Trying kubectl to inspect pod spec..."
    # Try kubectl
    if has_kubectl; then
      apiserver_proc=$(_rcmd "kubectl get pod -nkube-system -lcomponent=kube-apiserver -o=jsonpath='{range .items[*]}{.spec.containers[*].command}{\"\n\"}{end}'" 2>/dev/null || true)
      # Normalize JSON array to space-separated args (e.g. ["cmd","--arg=val"] → cmd --arg=val)
      if [[ "$apiserver_proc" == \[* ]]; then
        apiserver_proc=$(echo "$apiserver_proc" | sed 's/^\[\"//; s/\"\]$//; s/\",\"/ /g')
      fi
    fi
  fi

  if [[ -z "$apiserver_proc" ]]; then
    info "Cannot find kube-apiserver process or pod. Skipping section 1.2."
    for check_id in 1.2.{1..30}; do
      result_skip "$check_id" "API Server check" "kube-apiserver not found"
    done
    return
  fi

  local _audit
  _audit=$(format_proc_args "$apiserver_proc" "kube-apiserver")
  _AUDIT_CONTEXT="$_audit"

  # 1.2.1 (Manual)
  local id="1.2.1"
  local desc="Ensure that the --anonymous-auth argument is set to false (Manual)"
  local val
  val=$(get_argument_value "$apiserver_proc" "--anonymous-auth")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    result_warn "$id" "$desc" "--anonymous-auth not explicitly set (defaults to true)"
  else
    result_fail "$id" "$desc" "--anonymous-auth is set to $val"
  fi

  # 1.2.2
  id="1.2.2"
  desc="Ensure that the --token-auth-file parameter is not set (Automated)"
  if has_argument "$apiserver_proc" "--token-auth-file"; then
    result_fail "$id" "$desc" "--token-auth-file is set"
  else
    result_pass "$id" "$desc"
  fi

  # 1.2.3 (Manual)
  id="1.2.3"
  desc="Ensure that the DenyServiceExternalIPs is set (Manual)"
  local admission_plugins
  admission_plugins=$(get_argument_value "$apiserver_proc" "--enable-admission-plugins")
  if echo "$admission_plugins" | grep -qi "DenyServiceExternalIPs"; then
    result_pass "$id" "$desc"
  else
    result_warn "$id" "$desc" "DenyServiceExternalIPs not found in --enable-admission-plugins"
  fi

  # 1.2.4
  id="1.2.4"
  desc="Ensure that the --kubelet-client-certificate and --kubelet-client-key arguments are set as appropriate (Automated)"
  local kubelet_cert kubelet_key
  kubelet_cert=$(get_argument_value "$apiserver_proc" "--kubelet-client-certificate")
  kubelet_key=$(get_argument_value "$apiserver_proc" "--kubelet-client-key")
  if [[ -n "$kubelet_cert" && -n "$kubelet_key" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "kubelet-client-certificate=${kubelet_cert:-unset}, kubelet-client-key=${kubelet_key:-unset}"
  fi

  # 1.2.5
  id="1.2.5"
  desc="Ensure that the --kubelet-certificate-authority argument is set as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--kubelet-certificate-authority")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--kubelet-certificate-authority is not set"
  fi

  # 1.2.6
  id="1.2.6"
  desc="Ensure that the --authorization-mode argument is not set to AlwaysAllow (Automated)"
  local auth_mode
  auth_mode=$(get_argument_value "$apiserver_proc" "--authorization-mode")
  if [[ -z "$auth_mode" ]]; then
    result_warn "$id" "$desc" "--authorization-mode is not set"
  elif echo "$auth_mode" | grep -qi "AlwaysAllow"; then
    result_fail "$id" "$desc" "--authorization-mode includes AlwaysAllow: $auth_mode"
  else
    result_pass "$id" "$desc"
  fi

  # 1.2.7
  id="1.2.7"
  desc="Ensure that the --authorization-mode argument includes Node (Automated)"
  if echo "$auth_mode" | grep -qi "Node"; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--authorization-mode does not include Node: ${auth_mode:-unset}"
  fi

  # 1.2.8
  id="1.2.8"
  desc="Ensure that the --authorization-mode argument includes RBAC (Automated)"
  if echo "$auth_mode" | grep -qi "RBAC"; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--authorization-mode does not include RBAC: ${auth_mode:-unset}"
  fi

  # 1.2.9 (Manual)
  id="1.2.9"
  desc="Ensure that the admission control plugin EventRateLimit is set (Manual)"
  if echo "$admission_plugins" | grep -qi "EventRateLimit"; then
    result_pass "$id" "$desc"
  else
    result_warn "$id" "$desc" "EventRateLimit not found in --enable-admission-plugins"
  fi

  # 1.2.10
  id="1.2.10"
  desc="Ensure that the admission control plugin AlwaysAdmit is not set (Automated)"
  if echo "$admission_plugins" | grep -qi "AlwaysAdmit"; then
    result_fail "$id" "$desc" "AlwaysAdmit found in --enable-admission-plugins"
  else
    result_pass "$id" "$desc"
  fi

  # 1.2.11 (Manual)
  id="1.2.11"
  desc="Ensure that the admission control plugin AlwaysPullImages is set (Manual)"
  if echo "$admission_plugins" | grep -qi "AlwaysPullImages"; then
    result_pass "$id" "$desc"
  else
    result_warn "$id" "$desc" "AlwaysPullImages not found in --enable-admission-plugins"
  fi

  # 1.2.12
  id="1.2.12"
  desc="Ensure that the admission control plugin ServiceAccount is set (Automated)"
  local disable_plugins
  disable_plugins=$(get_argument_value "$apiserver_proc" "--disable-admission-plugins")
  if echo "$disable_plugins" | grep -qi "ServiceAccount"; then
    result_fail "$id" "$desc" "ServiceAccount found in --disable-admission-plugins"
  else
    result_pass "$id" "$desc"
  fi

  # 1.2.13
  id="1.2.13"
  desc="Ensure that the admission control plugin NamespaceLifecycle is set (Automated)"
  if echo "$disable_plugins" | grep -qi "NamespaceLifecycle"; then
    result_fail "$id" "$desc" "NamespaceLifecycle found in --disable-admission-plugins"
  else
    result_pass "$id" "$desc"
  fi

  # 1.2.14
  id="1.2.14"
  desc="Ensure that the admission control plugin NodeRestriction is set (Automated)"
  if echo "$admission_plugins" | grep -qi "NodeRestriction"; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "NodeRestriction not found in --enable-admission-plugins"
  fi

  # 1.2.15
  id="1.2.15"
  desc="Ensure that the --profiling argument is set to false (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--profiling")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--profiling is ${val:-not set (defaults to true)}"
  fi

  # 1.2.16
  id="1.2.16"
  desc="Ensure that the --audit-log-path argument is set (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--audit-log-path")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--audit-log-path is not set"
  fi

  # 1.2.17
  id="1.2.17"
  desc="Ensure that the --audit-log-maxage argument is set to 30 or as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--audit-log-maxage")
  if [[ -n "$val" ]] && (( val >= 30 )); then
    result_pass "$id" "$desc"
  elif [[ -n "$val" ]]; then
    result_fail "$id" "$desc" "--audit-log-maxage is $val (should be >= 30)"
  else
    result_fail "$id" "$desc" "--audit-log-maxage is not set"
  fi

  # 1.2.18
  id="1.2.18"
  desc="Ensure that the --audit-log-maxbackup argument is set to 10 or as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--audit-log-maxbackup")
  if [[ -n "$val" ]] && (( val >= 10 )); then
    result_pass "$id" "$desc"
  elif [[ -n "$val" ]]; then
    result_fail "$id" "$desc" "--audit-log-maxbackup is $val (should be >= 10)"
  else
    result_fail "$id" "$desc" "--audit-log-maxbackup is not set"
  fi

  # 1.2.19
  id="1.2.19"
  desc="Ensure that the --audit-log-maxsize argument is set to 100 or as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--audit-log-maxsize")
  if [[ -n "$val" ]] && (( val >= 100 )); then
    result_pass "$id" "$desc"
  elif [[ -n "$val" ]]; then
    result_fail "$id" "$desc" "--audit-log-maxsize is $val (should be >= 100)"
  else
    result_fail "$id" "$desc" "--audit-log-maxsize is not set"
  fi

  # 1.2.20 (Manual)
  id="1.2.20"
  desc="Ensure that the --request-timeout argument is set as appropriate (Manual)"
  val=$(get_argument_value "$apiserver_proc" "--request-timeout")
  if [[ -z "$val" ]]; then
    result_pass "$id" "$desc"  # default 60s is acceptable
  else
    result_info "$id" "$desc" "--request-timeout is set to $val (verify appropriateness)"
  fi

  # 1.2.21
  id="1.2.21"
  desc="Ensure that the --service-account-lookup argument is set to true (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--service-account-lookup")
  if [[ "$val" == "true" ]] || [[ -z "$val" ]]; then
    result_pass "$id" "$desc"  # defaults to true
  else
    result_fail "$id" "$desc" "--service-account-lookup is set to $val"
  fi

  # 1.2.22
  id="1.2.22"
  desc="Ensure that the --service-account-key-file argument is set as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--service-account-key-file")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--service-account-key-file is not set"
  fi

  # 1.2.23
  id="1.2.23"
  desc="Ensure that the --etcd-certfile and --etcd-keyfile arguments are set as appropriate (Automated)"
  local etcd_cert etcd_key
  etcd_cert=$(get_argument_value "$apiserver_proc" "--etcd-certfile")
  etcd_key=$(get_argument_value "$apiserver_proc" "--etcd-keyfile")
  if [[ -n "$etcd_cert" && -n "$etcd_key" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "etcd-certfile=${etcd_cert:-unset}, etcd-keyfile=${etcd_key:-unset}"
  fi

  # 1.2.24
  id="1.2.24"
  desc="Ensure that the --tls-cert-file and --tls-private-key-file arguments are set as appropriate (Automated)"
  local tls_cert tls_key
  tls_cert=$(get_argument_value "$apiserver_proc" "--tls-cert-file")
  tls_key=$(get_argument_value "$apiserver_proc" "--tls-private-key-file")
  if [[ -n "$tls_cert" && -n "$tls_key" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "tls-cert-file=${tls_cert:-unset}, tls-private-key-file=${tls_key:-unset}"
  fi

  # 1.2.25
  id="1.2.25"
  desc="Ensure that the --client-ca-file argument is set as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--client-ca-file")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--client-ca-file is not set"
  fi

  # 1.2.26
  id="1.2.26"
  desc="Ensure that the --etcd-cafile argument is set as appropriate (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--etcd-cafile")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--etcd-cafile is not set"
  fi

  # 1.2.27 (Manual)
  id="1.2.27"
  desc="Ensure that the --encryption-provider-config argument is set as appropriate (Manual)"
  val=$(get_argument_value "$apiserver_proc" "--encryption-provider-config")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_warn "$id" "$desc" "--encryption-provider-config is not set"
  fi

  # 1.2.28 (Manual)
  id="1.2.28"
  desc="Ensure that encryption providers are appropriately configured (Manual)"
  local enc_config
  enc_config=$(get_argument_value "$apiserver_proc" "--encryption-provider-config")
  if [[ -n "$enc_config" && -f "$enc_config" ]]; then
    if grep -qE "aescbc|kms|secretbox" "$enc_config" 2>/dev/null; then
      result_pass "$id" "$desc"
    else
      result_warn "$id" "$desc" "Encryption config exists but no strong provider (aescbc/kms/secretbox) found"
    fi
  else
    result_warn "$id" "$desc" "No encryption provider config to inspect"
  fi

  # 1.2.29 (Manual)
  id="1.2.29"
  desc="Ensure that the API Server only makes use of Strong Cryptographic Ciphers (Manual)"
  val=$(get_argument_value "$apiserver_proc" "--tls-cipher-suites")
  local insecure_ciphers="CBC|RC4|3DES"
  if [[ -n "$val" ]]; then
    if echo "$val" | grep -qE "$insecure_ciphers"; then
      result_fail "$id" "$desc" "Insecure ciphers found in --tls-cipher-suites: $val"
    else
      result_pass "$id" "$desc"
    fi
  else
    result_warn "$id" "$desc" "--tls-cipher-suites not set (uses default which may include weak ciphers)"
  fi

  # 1.2.30
  id="1.2.30"
  desc="Ensure that the --service-account-extend-token-expiration parameter is set to false (Automated)"
  val=$(get_argument_value "$apiserver_proc" "--service-account-extend-token-expiration")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    result_fail "$id" "$desc" "--service-account-extend-token-expiration not set (defaults to true)"
  else
    result_fail "$id" "$desc" "--service-account-extend-token-expiration is $val"
  fi

  _AUDIT_CONTEXT=""
}

run_1_3() {
  header "1.3 - Controller Manager"

  local cm_proc
  cm_proc=$(get_process_args "kube-controller-manager" || true)

  if [[ -z "$cm_proc" ]]; then
    info "kube-controller-manager process not found. Skipping section 1.3."
    for check_id in 1.3.{1..7}; do
      result_skip "$check_id" "Controller Manager check" "kube-controller-manager not found"
    done
    return
  fi

  _AUDIT_CONTEXT=$(format_proc_args "$cm_proc" "kube-controller-manager")
  local id desc val

  # 1.3.1 (Manual)
  id="1.3.1"
  desc="Ensure that the --terminated-pod-gc-threshold argument is set as appropriate (Manual)"
  val=$(get_argument_value "$cm_proc" "--terminated-pod-gc-threshold")
  if [[ -n "$val" ]]; then
    result_info "$id" "$desc" "--terminated-pod-gc-threshold is set to $val"
  else
    result_warn "$id" "$desc" "--terminated-pod-gc-threshold is not set (defaults to 12500)"
  fi

  # 1.3.2
  id="1.3.2"
  desc="Ensure that the --profiling argument is set to false (Automated)"
  val=$(get_argument_value "$cm_proc" "--profiling")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--profiling is ${val:-not set (defaults to true)}"
  fi

  # 1.3.3
  id="1.3.3"
  desc="Ensure that the --use-service-account-credentials argument is set to true (Automated)"
  val=$(get_argument_value "$cm_proc" "--use-service-account-credentials")
  if [[ "$val" == "true" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--use-service-account-credentials is ${val:-not set (defaults to false)}"
  fi

  # 1.3.4
  id="1.3.4"
  desc="Ensure that the --service-account-private-key-file argument is set as appropriate (Automated)"
  val=$(get_argument_value "$cm_proc" "--service-account-private-key-file")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--service-account-private-key-file is not set"
  fi

  # 1.3.5
  id="1.3.5"
  desc="Ensure that the --root-ca-file argument is set as appropriate (Automated)"
  val=$(get_argument_value "$cm_proc" "--root-ca-file")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--root-ca-file is not set"
  fi

  # 1.3.6
  id="1.3.6"
  desc="Ensure that the RotateKubeletServerCertificate argument is set to true (Automated)"
  local feature_gates
  feature_gates=$(get_argument_value "$cm_proc" "--feature-gates")
  if echo "$feature_gates" | grep -qi "RotateKubeletServerCertificate=true"; then
    result_pass "$id" "$desc"
  elif [[ -z "$feature_gates" ]] || ! echo "$feature_gates" | grep -qi "RotateKubeletServerCertificate"; then
    # Default is true since Kubernetes v1.12+
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "RotateKubeletServerCertificate is not true in --feature-gates"
  fi

  # 1.3.7
  id="1.3.7"
  desc="Ensure that the --bind-address argument is set to 127.0.0.1 (Automated)"
  val=$(get_argument_value "$cm_proc" "--bind-address")
  if [[ "$val" == "127.0.0.1" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    result_fail "$id" "$desc" "--bind-address not set (defaults to 0.0.0.0)"
  else
    result_fail "$id" "$desc" "--bind-address is $val"
  fi

  _AUDIT_CONTEXT=""
}

run_1_4() {
  header "1.4 - Scheduler"

  local sched_proc
  sched_proc=$(get_process_args "kube-scheduler" || true)

  if [[ -z "$sched_proc" ]]; then
    info "kube-scheduler process not found. Skipping section 1.4."
    for check_id in 1.4.{1..2}; do
      result_skip "$check_id" "Scheduler check" "kube-scheduler not found"
    done
    return
  fi

  _AUDIT_CONTEXT=$(format_proc_args "$sched_proc" "kube-scheduler")
  local id desc val

  # 1.4.1
  id="1.4.1"
  desc="Ensure that the --profiling argument is set to false (Automated)"
  val=$(get_argument_value "$sched_proc" "--profiling")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--profiling is ${val:-not set (defaults to true)}"
  fi

  # 1.4.2
  id="1.4.2"
  desc="Ensure that the --bind-address argument is set to 127.0.0.1 (Automated)"
  val=$(get_argument_value "$sched_proc" "--bind-address")
  if [[ "$val" == "127.0.0.1" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    result_fail "$id" "$desc" "--bind-address not set (defaults to 0.0.0.0)"
  else
    result_fail "$id" "$desc" "--bind-address is $val"
  fi

  _AUDIT_CONTEXT=""
}

###############################################################################
# 2 - etcd
###############################################################################

run_2() {
  header "2 - etcd"

  local etcd_proc
  etcd_proc=$(get_process_args "etcd" || true)
  # Filter out kube-apiserver etcd flags
  if echo "$etcd_proc" | grep -q "kube-apiserver"; then
    etcd_proc=$(_rcmd "ps -ef 2>/dev/null | grep -v grep | grep 'bin/etcd\\|/etcd ' | grep -v kube-apiserver | head -1" || true)
  fi

  if [[ -z "$etcd_proc" ]]; then
    info "etcd process not found. Skipping section 2."
    for check_id in 2.{1..7}; do
      result_skip "$check_id" "etcd check" "etcd process not found"
    done
    return
  fi

  _AUDIT_CONTEXT=$(format_proc_args "$etcd_proc" "etcd")
  local id desc val

  # 2.1
  id="2.1"
  desc="Ensure that the --cert-file and --key-file arguments are set as appropriate (Automated)"
  local cert_file key_file
  cert_file=$(get_argument_value "$etcd_proc" "--cert-file")
  key_file=$(get_argument_value "$etcd_proc" "--key-file")
  if [[ -n "$cert_file" && -n "$key_file" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "cert-file=${cert_file:-unset}, key-file=${key_file:-unset}"
  fi

  # 2.2
  id="2.2"
  desc="Ensure that the --client-cert-auth argument is set to true (Automated)"
  val=$(get_argument_value "$etcd_proc" "--client-cert-auth")
  if [[ "$val" == "true" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--client-cert-auth is ${val:-not set}"
  fi

  # 2.3
  id="2.3"
  desc="Ensure that the --auto-tls argument is not set to true (Automated)"
  val=$(get_argument_value "$etcd_proc" "--auto-tls")
  if [[ "$val" == "true" ]]; then
    result_fail "$id" "$desc" "--auto-tls is true"
  else
    result_pass "$id" "$desc"
  fi

  # 2.4
  id="2.4"
  desc="Ensure that the --peer-cert-file and --peer-key-file arguments are set as appropriate (Automated)"
  local peer_cert peer_key
  peer_cert=$(get_argument_value "$etcd_proc" "--peer-cert-file")
  peer_key=$(get_argument_value "$etcd_proc" "--peer-key-file")
  if [[ -n "$peer_cert" && -n "$peer_key" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "peer-cert-file=${peer_cert:-unset}, peer-key-file=${peer_key:-unset}"
  fi

  # 2.5
  id="2.5"
  desc="Ensure that the --peer-client-cert-auth argument is set to true (Automated)"
  val=$(get_argument_value "$etcd_proc" "--peer-client-cert-auth")
  if [[ "$val" == "true" ]]; then
    result_pass "$id" "$desc"
  else
    result_fail "$id" "$desc" "--peer-client-cert-auth is ${val:-not set}"
  fi

  # 2.6
  id="2.6"
  desc="Ensure that the --peer-auto-tls argument is not set to true (Automated)"
  val=$(get_argument_value "$etcd_proc" "--peer-auto-tls")
  if [[ "$val" == "true" ]]; then
    result_fail "$id" "$desc" "--peer-auto-tls is true"
  else
    result_pass "$id" "$desc"
  fi

  # 2.7 (Manual)
  id="2.7"
  desc="Ensure that a unique Certificate Authority is used for etcd (Manual)"
  local etcd_ca
  etcd_ca=$(get_argument_value "$etcd_proc" "--trusted-ca-file")
  local apiserver_proc_tmp
  apiserver_proc_tmp=$(get_process_args "kube-apiserver" || true)
  local api_ca
  api_ca=$(get_argument_value "${apiserver_proc_tmp}" "--client-ca-file")
  if [[ -n "$etcd_ca" && -n "$api_ca" ]]; then
    if [[ "$etcd_ca" != "$api_ca" ]]; then
      result_pass "$id" "$desc"
    else
      result_warn "$id" "$desc" "etcd and API server appear to use the same CA file: $etcd_ca"
    fi
  else
    result_warn "$id" "$desc" "Could not determine CA files for comparison"
  fi

  _AUDIT_CONTEXT=""
}

###############################################################################
# 3 - Control Plane Configuration
###############################################################################

run_3() {
  header "3 - Control Plane Configuration"

  local id desc

  # 3.1 Authentication and Authorization (all Manual)
  # 3.1.1
  id="3.1.1"
  desc="Client certificate authentication should not be used for users (Manual)"
  result_info "$id" "$desc" "Review user access: ensure users are not using client certificate authentication for API access"

  # 3.1.2
  id="3.1.2"
  desc="Service account token authentication should not be used for users (Manual)"
  result_info "$id" "$desc" "Review user access: ensure users are not using service account tokens for API access"

  # 3.1.3
  id="3.1.3"
  desc="Bootstrap token authentication should not be used for users (Manual)"
  result_info "$id" "$desc" "Review user access: ensure users are not using bootstrap tokens for API access"

  # 3.2 Logging
  local apiserver_proc
  apiserver_proc=$(get_process_args "kube-apiserver" || true)

  # 3.2.1 (Manual)
  id="3.2.1"
  desc="Ensure that a minimal audit policy is created (Manual)"
  if [[ -n "$apiserver_proc" ]]; then
    local audit_policy
    audit_policy=$(get_argument_value "$apiserver_proc" "--audit-policy-file")
    if [[ -n "$audit_policy" ]]; then
      if _test_f "$audit_policy"; then
        result_pass "$id" "$desc"
      else
        result_warn "$id" "$desc" "--audit-policy-file is set to $audit_policy but file not found"
      fi
    else
      result_fail "$id" "$desc" "--audit-policy-file is not set" "$(format_proc_args "$apiserver_proc" "kube-apiserver")"
    fi
  else
    result_skip "$id" "$desc" "kube-apiserver not found"
  fi

  # 3.2.2 (Manual)
  id="3.2.2"
  desc="Ensure that the audit policy covers key security concerns (Manual)"
  if [[ -n "$apiserver_proc" ]]; then
    local audit_policy
    audit_policy=$(get_argument_value "$apiserver_proc" "--audit-policy-file")
    if [[ -n "$audit_policy" ]] && _test_f "$audit_policy"; then
      local covers_secrets covers_pods
      covers_secrets=$(_rcmd "grep -c 'secrets' '$audit_policy'" 2>/dev/null || true)
      covers_pods=$(_rcmd "grep -c -E 'pods|deployments' '$audit_policy'" 2>/dev/null || true)
      if (( covers_secrets > 0 && covers_pods > 0 )); then
        result_pass "$id" "$desc"
      else
        result_warn "$id" "$desc" "Audit policy may not cover secrets or pod modifications"
      fi
    else
      result_warn "$id" "$desc" "No audit policy file to review"
    fi
  else
    result_skip "$id" "$desc" "kube-apiserver not found"
  fi
}

###############################################################################
# 4 - Worker Nodes
###############################################################################

run_4_1() {
  header "4.1 - Worker Node Configuration Files"

  local id desc

  # 4.1.1
  check_file_perms "4.1.1" \
    "Ensure that the kubelet service file permissions are set to 600 or more restrictive (Automated)" \
    "$KUBELET_SVC" "600"

  # 4.1.2
  check_file_owner "4.1.2" \
    "Ensure that the kubelet service file ownership is set to root:root (Automated)" \
    "$KUBELET_SVC" "root:root"

  # 4.1.3 (Manual)
  id="4.1.3"
  desc="If proxy kubeconfig file exists ensure permissions are set to 600 or more restrictive (Manual)"
  local kube_proxy_proc proxy_kubeconfig
  kube_proxy_proc=$(get_process_args "kube-proxy" || true)
  proxy_kubeconfig=$(get_argument_value "$kube_proxy_proc" "--kubeconfig")
  if [[ -n "$proxy_kubeconfig" ]] && _test_f "$proxy_kubeconfig"; then
    check_file_perms "$id" "$desc" "$proxy_kubeconfig" "600"
  else
    result_info "$id" "$desc" "kube-proxy kubeconfig not found or kube-proxy not running with file-based config"
  fi

  # 4.1.4 (Manual)
  id="4.1.4"
  desc="If proxy kubeconfig file exists ensure ownership is set to root:root (Manual)"
  if [[ -n "$proxy_kubeconfig" ]] && _test_f "$proxy_kubeconfig"; then
    check_file_owner "$id" "$desc" "$proxy_kubeconfig" "root:root"
  else
    result_info "$id" "$desc" "kube-proxy kubeconfig not found or kube-proxy not running with file-based config"
  fi

  # 4.1.5
  check_file_perms "4.1.5" \
    "Ensure that the --kubeconfig kubelet.conf file permissions are set to 600 or more restrictive (Automated)" \
    "$KUBELET_CONF" "600"

  # 4.1.6
  check_file_owner "4.1.6" \
    "Ensure that the --kubeconfig kubelet.conf file ownership is set to root:root (Automated)" \
    "$KUBELET_CONF" "root:root"

  # 4.1.7 (Manual)
  id="4.1.7"
  desc="Ensure that the certificate authorities file permissions are set to 644 or more restrictive (Manual)"
  local kubelet_proc client_ca_file
  kubelet_proc=$(get_process_args "kubelet" || true)
  client_ca_file=$(get_argument_value "$kubelet_proc" "--client-ca-file")
  if [[ -z "$client_ca_file" ]] && _test_f "$KUBELET_CONFIG_YAML"; then
    client_ca_file=$(_rcmd "grep -A1 'clientCAFile' '$KUBELET_CONFIG_YAML' 2>/dev/null | grep -oP ':\s*\K\S+' | head -1" || true)
  fi
  if [[ -n "$client_ca_file" ]] && _test_f "$client_ca_file"; then
    check_file_perms "$id" "$desc" "$client_ca_file" "644"
  else
    result_info "$id" "$desc" "client-ca-file not specified or not found"
  fi

  # 4.1.8 (Manual)
  id="4.1.8"
  desc="Ensure that the client certificate authorities file ownership is set to root:root (Manual)"
  if [[ -n "$client_ca_file" ]] && _test_f "$client_ca_file"; then
    check_file_owner "$id" "$desc" "$client_ca_file" "root:root"
  else
    result_info "$id" "$desc" "client-ca-file not specified or not found"
  fi

  # 4.1.9
  check_file_perms "4.1.9" \
    "If the kubelet config.yaml configuration file is being used validate permissions set to 600 or more restrictive (Automated)" \
    "$KUBELET_CONFIG_YAML" "600"

  # 4.1.10
  check_file_owner "4.1.10" \
    "If the kubelet config.yaml configuration file is being used validate file ownership is set to root:root (Automated)" \
    "$KUBELET_CONFIG_YAML" "root:root"
}

run_4_2() {
  header "4.2 - Kubelet"

  local kubelet_proc
  kubelet_proc=$(get_process_args "kubelet" || true)

  if [[ -z "$kubelet_proc" ]]; then
    info "kubelet process not found. Skipping section 4.2."
    for check_id in 4.2.{1..14}; do
      result_skip "$check_id" "Kubelet check" "kubelet not found"
    done
    return
  fi

  _AUDIT_CONTEXT=$(format_proc_args "$kubelet_proc" "kubelet")
  if _test_f "$KUBELET_CONFIG_YAML"; then
    _AUDIT_CONTEXT+=$'\n'"$ cat $KUBELET_CONFIG_YAML"$'\n'"$(_rcmd "cat '$KUBELET_CONFIG_YAML'" 2>/dev/null || true)"
  fi
  local id desc val

  # 4.2.1
  id="4.2.1"
  desc="Ensure that the --anonymous-auth argument is set to false (Automated)"
  val=$(get_argument_value "$kubelet_proc" "--anonymous-auth")
  if [[ "$val" == "false" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    # Check kubelet config yaml
    local yaml_val
    yaml_val=$(get_kubelet_config_value "anonymous" || true)
    if echo "$yaml_val" | grep -qi "false"; then
      result_pass "$id" "$desc"
    else
      result_fail "$id" "$desc" "--anonymous-auth not set to false"
    fi
  else
    result_fail "$id" "$desc" "--anonymous-auth is $val"
  fi

  # 4.2.2
  id="4.2.2"
  desc="Ensure that the --authorization-mode argument is not set to AlwaysAllow (Automated)"
  val=$(get_argument_value "$kubelet_proc" "--authorization-mode")
  if [[ "$val" == "AlwaysAllow" ]]; then
    result_fail "$id" "$desc" "--authorization-mode is AlwaysAllow"
  elif [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    # Check config yaml
    local yaml_auth
    yaml_auth=$(get_kubelet_config_value "authorization" || true)
    if echo "$yaml_auth" | grep -qi "AlwaysAllow"; then
      result_fail "$id" "$desc" "authorization mode is AlwaysAllow in config"
    else
      result_pass "$id" "$desc"
    fi
  fi

  # 4.2.3
  id="4.2.3"
  desc="Ensure that the --client-ca-file argument is set as appropriate (Automated)"
  val=$(get_argument_value "$kubelet_proc" "--client-ca-file")
  if [[ -n "$val" ]]; then
    result_pass "$id" "$desc"
  else
    # Check config yaml
    local yaml_ca
    yaml_ca=$(get_kubelet_config_value "clientCAFile" || true)
    if [[ -n "$yaml_ca" ]]; then
      result_pass "$id" "$desc"
    else
      result_fail "$id" "$desc" "--client-ca-file is not set"
    fi
  fi

  # 4.2.4 (Manual)
  id="4.2.4"
  desc="Verify that if defined, readOnlyPort is set to 0 (Manual)"
  val=$(get_argument_value "$kubelet_proc" "--read-only-port")
  if [[ "$val" == "0" ]]; then
    result_pass "$id" "$desc"
  elif [[ -z "$val" ]]; then
    local yaml_port
    yaml_port=$(get_kubelet_config_value "readOnlyPort" || true)
    if [[ "$yaml_port" == "0" ]]; then
      result_pass "$id" "$desc"
    elif [[ -z "$yaml_port" ]]; then
      result_warn "$id" "$desc" "readOnlyPort not explicitly set (default is 10255)"
    else
      result_fail "$id" "$desc" "readOnlyPort is $yaml_port"
    fi
  else
    result_fail "$id" "$desc" "--read-only-port is $val"
  fi

  # 4.2.5 (Manual)
  id="4.2.5"
  desc="Ensure that the --streaming-connection-idle-timeout argument is not set to 0 (Manual)"
  val=$(get_argument_value "$kubelet_proc" "--streaming-connection-idle-timeout")
  if [[ "$val" == "0" ]]; then
    result_fail "$id" "$desc" "--streaming-connection-idle-timeout is 0"
  else
    result_pass "$id" "$desc"
  fi

  # 4.2.6
  id="4.2.6"
  desc="Ensure that the --make-iptables-util-chains argument is set to true (Automated)"
  val=$(get_argument_value "$kubelet_proc" "--make-iptables-util-chains")
  if [[ "$val" == "false" ]]; then
    result_fail "$id" "$desc" "--make-iptables-util-chains is false"
  else
    result_pass "$id" "$desc"  # defaults to true
  fi

  # 4.2.7 (Manual)
  id="4.2.7"
  desc="Ensure that the --hostname-override argument is not set (Manual)"
  if has_argument "$kubelet_proc" "--hostname-override"; then
    result_warn "$id" "$desc" "--hostname-override is set (may be required by cloud provider)"
  else
    result_pass "$id" "$desc"
  fi

  # 4.2.8 (Manual)
  id="4.2.8"
  desc="Ensure that the eventRecordQPS argument is set to a level which ensures appropriate event capture (Manual)"
  val=$(get_argument_value "$kubelet_proc" "--event-qps")
  if [[ -z "$val" ]]; then
    local yaml_qps
    yaml_qps=$(get_kubelet_config_value "eventRecordQPS" || true)
    if [[ -n "$yaml_qps" ]]; then
      if [[ "$yaml_qps" == "0" ]]; then
        result_warn "$id" "$desc" "eventRecordQPS is 0 (unlimited, potential DoS risk)"
      else
        result_info "$id" "$desc" "eventRecordQPS is $yaml_qps"
      fi
    else
      result_info "$id" "$desc" "eventRecordQPS not set (defaults to 5)"
    fi
  elif [[ "$val" == "0" ]]; then
    result_warn "$id" "$desc" "--event-qps is 0 (unlimited)"
  else
    result_info "$id" "$desc" "--event-qps is $val"
  fi

  # 4.2.9 (Manual)
  id="4.2.9"
  desc="Ensure that the --tls-cert-file and --tls-private-key-file arguments are set as appropriate (Manual)"
  local tls_cert tls_key
  tls_cert=$(get_argument_value "$kubelet_proc" "--tls-cert-file")
  tls_key=$(get_argument_value "$kubelet_proc" "--tls-private-key-file")
  if [[ -n "$tls_cert" && -n "$tls_key" ]]; then
    result_pass "$id" "$desc"
  else
    # Check config yaml
    local yaml_cert yaml_key
    yaml_cert=$(get_kubelet_config_value "tlsCertFile" || true)
    yaml_key=$(get_kubelet_config_value "tlsPrivateKeyFile" || true)
    if [[ -n "$yaml_cert" && -n "$yaml_key" ]]; then
      result_pass "$id" "$desc"
    else
      result_warn "$id" "$desc" "TLS cert/key not explicitly configured"
    fi
  fi

  # 4.2.10
  id="4.2.10"
  desc="Ensure that the --rotate-certificates argument is not set to false (Automated)"
  val=$(get_argument_value "$kubelet_proc" "--rotate-certificates")
  if [[ "$val" == "false" ]]; then
    result_fail "$id" "$desc" "--rotate-certificates is false"
  else
    result_pass "$id" "$desc"  # defaults to true
  fi

  # 4.2.11 (Manual)
  id="4.2.11"
  desc="Verify that the RotateKubeletServerCertificate argument is set to true (Manual)"
  # Check for --rotate-server-certificates or serverTLSBootstrap first
  if has_argument "$kubelet_proc" "--rotate-server-certificates"; then
    result_pass "$id" "$desc"
  else
    local yaml_bootstrap
    yaml_bootstrap=$(get_kubelet_config_value "serverTLSBootstrap" || true)
    if [[ "$yaml_bootstrap" == "true" ]]; then
      result_pass "$id" "$desc"
    else
      local feature_gates
      feature_gates=$(get_argument_value "$kubelet_proc" "--feature-gates")
      if echo "$feature_gates" | grep -qi "RotateKubeletServerCertificate=true"; then
        result_pass "$id" "$desc"
      elif echo "$feature_gates" | grep -qi "RotateKubeletServerCertificate=false"; then
        result_fail "$id" "$desc" "RotateKubeletServerCertificate is false"
      else
        result_pass "$id" "$desc"  # defaults to true since v1.12
      fi
    fi
  fi

  # 4.2.12 (Manual)
  id="4.2.12"
  desc="Ensure that the Kubelet only makes use of Strong Cryptographic Ciphers (Manual)"
  val=$(get_argument_value "$kubelet_proc" "--tls-cipher-suites")
  local insecure_ciphers="CBC|RC4|3DES"
  if [[ -n "$val" ]]; then
    if echo "$val" | grep -qE "$insecure_ciphers"; then
      result_fail "$id" "$desc" "Insecure ciphers found: $val"
    else
      result_pass "$id" "$desc"
    fi
  else
    # Check config yaml
    local yaml_ciphers
    yaml_ciphers=$(get_kubelet_config_value "tlsCipherSuites" || true)
    if [[ -n "$yaml_ciphers" ]]; then
      if echo "$yaml_ciphers" | grep -qE "$insecure_ciphers"; then
        result_fail "$id" "$desc" "Insecure ciphers in config: $yaml_ciphers"
      else
        result_pass "$id" "$desc"
      fi
    else
      result_warn "$id" "$desc" "TLS cipher suites not explicitly configured"
    fi
  fi

  # 4.2.13 (Manual)
  id="4.2.13"
  desc="Ensure that a limit is set on pod PIDs (Manual)"
  val=$(get_argument_value "$kubelet_proc" "--pod-max-pids")
  if [[ -n "$val" ]] && (( val > 0 )); then
    result_pass "$id" "$desc"
  else
    local yaml_pids
    yaml_pids=$(get_kubelet_config_value "PodPidsLimit\|podPidsLimit" || true)
    if [[ -n "$yaml_pids" ]] && [[ "$yaml_pids" != "-1" ]] && (( yaml_pids > 0 )); then
      result_pass "$id" "$desc"
    else
      result_warn "$id" "$desc" "No pod PID limit set"
    fi
  fi

  # 4.2.14 (Manual)
  id="4.2.14"
  desc="Ensure that the --seccomp-default parameter is set to true (Manual)"
  if has_argument "$kubelet_proc" "--seccomp-default"; then
    result_pass "$id" "$desc"
  else
    local yaml_seccomp
    yaml_seccomp=$(get_kubelet_config_value "seccompDefault" || true)
    if [[ "$yaml_seccomp" == "true" ]]; then
      result_pass "$id" "$desc"
    else
      result_warn "$id" "$desc" "seccomp-default not enabled"
    fi
  fi

  _AUDIT_CONTEXT=""
}

run_4_3() {
  header "4.3 - kube-proxy"

  local id desc
  local kube_proxy_proc
  kube_proxy_proc=$(get_process_args "kube-proxy" || true)

  # 4.3.1 (Manual)
  id="4.3.1"
  desc="Ensure that the kube-proxy metrics service is bound to localhost (Manual)"
  if [[ -n "$kube_proxy_proc" ]]; then
    local metrics_bind
    metrics_bind=$(get_argument_value "$kube_proxy_proc" "--metrics-bind-address")
    if [[ -z "$metrics_bind" ]]; then
      result_pass "$id" "$desc"  # default is 127.0.0.1:10249
    elif echo "$metrics_bind" | grep -q "127.0.0.1"; then
      result_pass "$id" "$desc"
    elif echo "$metrics_bind" | grep -q "localhost"; then
      result_pass "$id" "$desc"
    else
      result_fail "$id" "$desc" "--metrics-bind-address is $metrics_bind" "$(format_proc_args "$kube_proxy_proc" "kube-proxy")"
    fi
  else
    # Check if kube-proxy runs as a pod (DaemonSet)
    if has_kubectl; then
      local proxy_config
      proxy_config=$(_rcmd "kubectl get configmap -n kube-system kube-proxy -o jsonpath='{.data.config\\.conf}'" 2>/dev/null || true)
      if [[ -n "$proxy_config" ]]; then
        local mba
        mba=$(echo "$proxy_config" | grep "metricsBindAddress" | awk '{print $2}' || true)
        if [[ -z "$mba" ]] || echo "$mba" | grep -q "127.0.0.1"; then
          result_pass "$id" "$desc"
        else
          result_fail "$id" "$desc" "metricsBindAddress is $mba" "$ kubectl get configmap -n kube-system kube-proxy -o jsonpath='{.data.config.conf}'
$proxy_config"
        fi
      else
        result_info "$id" "$desc" "kube-proxy not found or ConfigMap not accessible"
      fi
    else
      result_skip "$id" "$desc" "kube-proxy not found and kubectl not available"
    fi
  fi
}

###############################################################################
# 5 - Policies
###############################################################################

run_5() {
  header "5 - Policies"

  if ! has_kubectl; then
    info "kubectl-compatible client not found. Skipping section 5 (requires cluster access)."
    local checks=(5.1.{1..13} 5.2.{1..12} 5.3.{1..2} 5.4.{1..2} 5.5.1 5.6.{1..4})
    for check_id in "${checks[@]}"; do
      result_skip "$check_id" "Policy check" "kubectl-compatible client not available"
    done
    return
  fi

  local ns_mode=false
  local pod_scope="-A"
  local object_scope="-A"
  if [[ -n "$NAMESPACE" ]]; then
    ns_mode=true
    pod_scope="-n '$NAMESPACE'"
    object_scope="-n '$NAMESPACE'"
    info "Namespace/project-scoped mode: $NAMESPACE"
  fi

  # Test API access without requiring cluster-wide permissions in namespace mode.
  if $ns_mode; then
    if ! _rcmd "kubectl get pods -n '$NAMESPACE' --request-timeout=10s -o name >/dev/null" &>/dev/null; then
      info "Cannot list pods in namespace/project '$NAMESPACE'. Skipping section 5."
      local checks=(5.1.{1..13} 5.2.{1..12} 5.3.{1..2} 5.4.{1..2} 5.5.1 5.6.{1..4})
      for check_id in "${checks[@]}"; do
        result_skip "$check_id" "Policy check" "No readable access to the selected namespace/project"
      done
      return
    fi
  else
    if ! _rcmd "kubectl cluster-info" &>/dev/null 2>&1; then
      info "Cannot connect to Kubernetes cluster. Skipping section 5."
      local checks=(5.1.{1..13} 5.2.{1..12} 5.3.{1..2} 5.4.{1..2} 5.5.1 5.6.{1..4})
      for check_id in "${checks[@]}"; do
        result_skip "$check_id" "Policy check" "Cannot connect to cluster"
      done
      return
    fi
  fi

  local id desc
  local can_list_roles=true can_list_rolebindings=true can_list_networkpolicies=true
  if $ns_mode; then
    [[ "$(_rcmd "kubectl auth can-i list roles -n '$NAMESPACE'" 2>/dev/null | tail -1)" == "yes" ]] || can_list_roles=false
    [[ "$(_rcmd "kubectl auth can-i list rolebindings -n '$NAMESPACE'" 2>/dev/null | tail -1)" == "yes" ]] || can_list_rolebindings=false
    [[ "$(_rcmd "kubectl auth can-i list networkpolicies -n '$NAMESPACE'" 2>/dev/null | tail -1)" == "yes" ]] || can_list_networkpolicies=false
  fi

  # 5.1 RBAC and Service Accounts
  header "5.1 - RBAC and Service Accounts"

  id="5.1.1"
  desc="Ensure that the cluster-admin role is only used where required (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "Requires cluster-scoped ClusterRoleBinding visibility; namespace mode only"
  else
    local clusteradmin_bindings
    clusteradmin_bindings=$(_rcmd "kubectl get clusterrolebindings -o=custom-columns=NAME:.metadata.name,ROLE:.roleRef.name,SUBJECT:.subjects[*].name" 2>/dev/null | grep cluster-admin || true)
    if [[ -n "$clusteradmin_bindings" ]]; then
      local binding_count
      binding_count=$(echo "$clusteradmin_bindings" | wc -l)
      result_info "$id" "$desc" "Found $binding_count cluster-admin binding(s) - review for necessity"
    else
      result_pass "$id" "$desc"
    fi
  fi

  id="5.1.2"
  desc="Minimize access to secrets (Manual)"
  if $ns_mode; then
    if $can_list_roles && $can_list_rolebindings; then
      result_info "$id" "$desc" "Review Roles/RoleBindings and effective secret access within the selected namespace/project"
    else
      result_skip "$id" "$desc" "Roles/RoleBindings are not both readable with the current namespace-scoped account"
    fi
  else
    result_info "$id" "$desc" "Review RBAC: check who has get/list/watch access to secrets"
  fi

  id="5.1.3"
  desc="Minimize wildcard use in Roles and ClusterRoles (Manual)"
  local wildcard_roles
  if $ns_mode; then
    if ! $can_list_roles; then
      result_skip "$id" "$desc" "Roles are not readable with the current namespace-scoped account"
    else
      wildcard_roles=$(_rcmd "kubectl get roles -n '$NAMESPACE' -o json" 2>/dev/null | grep -F -c '"*"' || true)
      if (( wildcard_roles > 0 )); then
        result_fail "$id" "$desc" "Found wildcard usage in $wildcard_roles namespaced Role rule/reference(s)" "$( _rcmd "kubectl get roles -n '$NAMESPACE' -o yaml" 2>/dev/null || true )"
      else
        result_pass "$id" "$desc"
      fi
    fi
  else
    wildcard_roles=$(_rcmd "kubectl get clusterroles -o json" 2>/dev/null | grep -F -c '"*"' || true)
    if (( wildcard_roles > 0 )); then
      result_warn "$id" "$desc" "Found wildcard usage in $wildcard_roles ClusterRole rule/reference(s)"
    else
      result_pass "$id" "$desc"
    fi
  fi

  id="5.1.4"
  desc="Minimize access to create pods (Manual)"
  if $ns_mode; then
    if $can_list_roles && $can_list_rolebindings; then
      result_info "$id" "$desc" "Review effective RBAC for create access to pods within the selected namespace/project"
    else
      result_skip "$id" "$desc" "Roles/RoleBindings are not both readable with the current namespace-scoped account"
    fi
  else
    result_info "$id" "$desc" "Review RBAC: check who has create access to pod objects"
  fi

  id="5.1.5"
  desc="Ensure that default service accounts are not actively used (Manual)"
  local active_defaults
  active_defaults=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.spec.serviceAccountName}{\"\\n\"}{end}'" 2>/dev/null | grep -c "^default$" || true)
  if (( active_defaults > 0 )); then
    result_fail "$id" "$desc" "$active_defaults pod(s) using the default service account" "$( _rcmd "kubectl get pods $pod_scope -o custom-columns=NAME:.metadata.name,SERVICEACCOUNT:.spec.serviceAccountName --no-headers" 2>/dev/null | awk '$2=="default"{print}' || true )"
  else
    result_pass "$id" "$desc"
  fi

  id="5.1.6"
  desc="Ensure that Service Account Tokens are only mounted where necessary (Manual)"
  local automount_count
  automount_count=$(_rcmd "kubectl get pods $pod_scope -o json" 2>/dev/null | grep -c '"automountServiceAccountToken": true' || true)
  result_info "$id" "$desc" "Review pods: $automount_count pod(s) explicitly set automountServiceAccountToken=true"

  id="5.1.7"
  desc="Avoid use of system:masters group (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "Requires cluster-scoped credential/RBAC visibility; namespace mode only"
  else
    result_info "$id" "$desc" "Review credentials: ensure system:masters group is not used for regular access"
  fi

  id="5.1.8"
  desc="Limit use of the Bind, Impersonate and Escalate permissions in the Kubernetes cluster (Manual)"
  if $ns_mode; then
    if $can_list_roles && $can_list_rolebindings; then
      result_info "$id" "$desc" "Review Roles and RoleBindings visible within the selected namespace/project; cluster-scoped grants are out of scope"
    else
      result_skip "$id" "$desc" "Roles/RoleBindings are not both readable with the current namespace-scoped account"
    fi
  else
    result_info "$id" "$desc" "Review RBAC for bind, impersonate, and escalate permissions"
  fi

  id="5.1.9"
  desc="Minimize access to create persistent volumes (Manual)"
  if $ns_mode; then result_skip "$id" "$desc" "PersistentVolumes are cluster-scoped; namespace mode only"
  else result_info "$id" "$desc" "Review RBAC: check who has create access to PersistentVolume objects"; fi

  id="5.1.10"
  desc="Minimize access to the proxy sub-resource of nodes (Manual)"
  if $ns_mode; then result_skip "$id" "$desc" "Nodes are cluster-scoped; namespace mode only"
  else result_info "$id" "$desc" "Review RBAC: check who has access to nodes/proxy"; fi

  id="5.1.11"
  desc="Minimize access to the approval sub-resource of certificatesigningrequests objects (Manual)"
  if $ns_mode; then result_skip "$id" "$desc" "CertificateSigningRequests are cluster-scoped; namespace mode only"
  else result_info "$id" "$desc" "Review RBAC: check who can update approval on CSRs"; fi

  id="5.1.12"
  desc="Minimize access to webhook configuration objects (Manual)"
  if $ns_mode; then result_skip "$id" "$desc" "Webhook configurations are cluster-scoped; namespace mode only"
  else result_info "$id" "$desc" "Review RBAC: check who can modify validating/mutating webhook configurations"; fi

  id="5.1.13"
  desc="Minimize access to the service account token creation (Manual)"
  if $ns_mode; then
    if $can_list_roles && $can_list_rolebindings; then
      result_info "$id" "$desc" "Review effective RBAC for the serviceaccounts/token sub-resource within the selected namespace/project"
    else
      result_skip "$id" "$desc" "Roles/RoleBindings are not both readable with the current namespace-scoped account"
    fi
  else
    result_info "$id" "$desc" "Review RBAC: check who can create token sub-resource of serviceaccounts"
  fi

  # 5.2 Pod Security Standards
  header "5.2 - Pod Security Standards"

  id="5.2.1"
  desc="Ensure that the cluster has at least one active policy control mechanism in place (Manual)"
  if $ns_mode; then
    local ns_json psa_enforce
    if ns_json=$(_rcmd "kubectl get namespace '$NAMESPACE' -o json" 2>/dev/null); then
      psa_enforce=$(printf '%s' "$ns_json" | grep -o '"pod-security.kubernetes.io/enforce"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 || true)
      if [[ -n "$psa_enforce" ]]; then
        result_pass "$id" "$desc"
      else
        result_info "$id" "$desc" "No Pod Security Admission enforce label visible on the selected namespace/project; review platform-specific admission controls separately"
      fi
    else
      result_skip "$id" "$desc" "Namespace metadata is not readable with the current account"
    fi
  else
    local psa_labels
    psa_labels=$(_rcmd "kubectl get namespaces -o jsonpath='{range .items[*]}{.metadata.name}: {.metadata.labels.pod-security\\.kubernetes\\.io/enforce}{\"\\n\"}{end}'" 2>/dev/null | grep -v ": $" || true)
    if [[ -n "$psa_labels" ]]; then result_pass "$id" "$desc"
    else result_warn "$id" "$desc" "No namespaces with Pod Security Admission labels found"; fi
  fi

  id="5.2.2"
  desc="Minimize the admission of privileged containers (Manual)"
  local privileged_pods
  privileged_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext.privileged}{\"\\n\"}{end}'" 2>/dev/null | grep "true" || true)
  if [[ -z "$privileged_pods" ]]; then result_pass "$id" "$desc"
  else local priv_count; priv_count=$(echo "$privileged_pods" | wc -l); result_fail "$id" "$desc" "$priv_count pod(s) running with privileged containers" "$privileged_pods"; fi

  id="5.2.3"
  desc="Minimize the admission of containers wishing to share the host process ID namespace (Manual)"
  local hostpid_pods
  hostpid_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostPID}{\"\\n\"}{end}'" 2>/dev/null | grep "true" || true)
  if [[ -z "$hostpid_pods" ]]; then result_pass "$id" "$desc"
  else local count; count=$(echo "$hostpid_pods" | wc -l); result_fail "$id" "$desc" "$count pod(s) with hostPID=true" "$hostpid_pods"; fi

  id="5.2.4"
  desc="Minimize the admission of containers wishing to share the host IPC namespace (Manual)"
  local hostipc_pods
  hostipc_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostIPC}{\"\\n\"}{end}'" 2>/dev/null | grep "true" || true)
  if [[ -z "$hostipc_pods" ]]; then result_pass "$id" "$desc"
  else local count; count=$(echo "$hostipc_pods" | wc -l); result_fail "$id" "$desc" "$count pod(s) with hostIPC=true" "$hostipc_pods"; fi

  id="5.2.5"
  desc="Minimize the admission of containers wishing to share the host network namespace (Manual)"
  local hostnet_pods
  hostnet_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@.spec.hostNetwork}{\"\\n\"}{end}'" 2>/dev/null | grep "true" || true)
  if [[ -z "$hostnet_pods" ]]; then result_pass "$id" "$desc"
  else local count; count=$(echo "$hostnet_pods" | wc -l); result_fail "$id" "$desc" "$count pod(s) with hostNetwork=true" "$hostnet_pods"; fi

  id="5.2.6"
  desc="Minimize the admission of containers with allowPrivilegeEscalation (Manual)"
  local ape_pods
  ape_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext.allowPrivilegeEscalation}{\"\\n\"}{end}'" 2>/dev/null | grep "true" || true)
  if [[ -z "$ape_pods" ]]; then result_pass "$id" "$desc"
  else local count; count=$(echo "$ape_pods" | wc -l); result_fail "$id" "$desc" "$count pod(s) with allowPrivilegeEscalation=true" "$ape_pods"; fi

  id="5.2.7"
  desc="Minimize root container use (Kubernetes/OpenShift policy check)"
  local root_pods nonroot_false
  root_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext.runAsUser}{"\n"}{end}'" 2>/dev/null | grep ": 0" || true)
  nonroot_false=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {@..securityContext.runAsNonRoot}{"\n"}{end}'" 2>/dev/null | grep "false" || true)
  if [[ -n "$root_pods" || -n "$nonroot_false" ]]; then
    local root_detail
    root_detail="${root_pods}${root_pods:+$'\n'}${nonroot_false}"
    result_fail "$id" "$desc" "Explicit root/non-root protection issue observed in one or more in-scope pods" "$root_detail"
  else
    result_info "$id" "$desc" "No pod explicitly sets runAsUser=0 or runAsNonRoot=false; effective UID may still be supplied by OpenShift SCC/admission"
  fi

  id="5.2.8"
  desc="Minimize NET_RAW capability use (Kubernetes/OpenShift policy check)"
  local netraw_pods
  netraw_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .spec.containers[*]}{.name}{":"}{.securityContext.capabilities.add}{" "}{end}{"\n"}{end}'" 2>/dev/null | grep -E 'NET_RAW' || true)
  if [[ -z "$netraw_pods" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "NET_RAW is explicitly added by one or more in-scope containers" "$netraw_pods"; fi

  id="5.2.9"
  desc="Minimize added Linux capabilities (Kubernetes/OpenShift policy check)"
  local caps_add
  caps_add=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .spec.containers[*]}{.name}{":"}{.securityContext.capabilities.add}{" "}{end}{"\n"}{end}'" 2>/dev/null | grep -E '\[[^]]+\]' || true)
  if [[ -z "$caps_add" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "One or more in-scope containers explicitly add Linux capabilities" "$caps_add"; fi

  id="5.2.10"
  desc="Minimize Windows HostProcess container use (Kubernetes policy check)"
  local hostprocess
  hostprocess=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{@..securityContext.windowsOptions.hostProcess}{"\n"}{end}'" 2>/dev/null | grep 'true' || true)
  if [[ -z "$hostprocess" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "One or more in-scope pods use Windows HostProcess" "$hostprocess"; fi

  id="5.2.11"
  desc="Minimize HostPath volume use (Kubernetes policy check)"
  local hostpath
  hostpath=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .spec.volumes[*]}{.name}{":"}{.hostPath.path}{" "}{end}{"\n"}{end}'" 2>/dev/null | grep -E ':[^[:space:]]' || true)
  if [[ -z "$hostpath" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "One or more in-scope pods mount hostPath volumes" "$hostpath"; fi

  id="5.2.12"
  desc="Minimize HostPort use (Kubernetes policy check)"
  local hostports
  hostports=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .spec.containers[*].ports[*]}{.hostPort}{" "}{end}{"\n"}{end}'" 2>/dev/null | grep -E '[1-9][0-9]*' || true)
  if [[ -z "$hostports" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "One or more in-scope pods define hostPort" "$hostports"; fi

  # OpenShift-specific workload evidence. The SCC annotation shows which SCC admitted a running pod.
  # This does not replace a cluster-wide SCC/RBAC assessment.
  if $ns_mode; then
    local scc_usage privileged_scc_pods
    scc_usage=$(_rcmd "kubectl get pods -n '$NAMESPACE' -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.metadata.annotations.openshift\.io/scc}{"\n"}{end}'" 2>/dev/null || true)
    if [[ -n "$scc_usage" ]] && printf '%s\n' "$scc_usage" | awk -F '\t' 'NF>1 && $2!="" {found=1} END{exit !found}'; then
      privileged_scc_pods=$(printf '%s\n' "$scc_usage" | awk -F '\t' '$2=="privileged" {print}' || true)
      if [[ -n "$privileged_scc_pods" ]]; then
        result_fail "OCP-SCC-OBS" "OpenShift privileged SCC use observed" "One or more in-scope pods were admitted using the privileged SCC" "$privileged_scc_pods"
      else
        result_info "OCP-SCC-OBS" "OpenShift SCC usage observed" "SCCs used by in-scope pods: $(printf '%s\n' "$scc_usage" | awk -F '\t' 'NF>1 && $2!="" {print $2}' | sort -u | paste -sd, -)"
      fi
    else
      result_info "OCP-SCC-OBS" "OpenShift SCC usage" "No openshift.io/scc pod annotations were visible; this may be a non-OpenShift cluster or the annotation may be unavailable"
    fi
  fi

  # 5.3 Network Policies and CNI
  header "5.3 - Network Policies and CNI"

  id="5.3.1"
  desc="Ensure that the CNI in use supports Network Policies (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "CNI configuration is cluster-level and not assessable from namespace-only access"
  else
    result_info "$id" "$desc" "Verify that the CNI plugin in use supports NetworkPolicy (e.g., Calico, Cilium)"
  fi

  id="5.3.2"
  desc="Ensure that all Namespaces have Network Policies defined (Manual)"
  if $ns_mode; then
    if ! $can_list_networkpolicies; then
      result_skip "$id" "$desc" "NetworkPolicies are not readable with the current namespace-scoped account"
    else
      local np_count
      np_count=$(_rcmd "kubectl get networkpolicy -n '$NAMESPACE' -o name" 2>/dev/null | grep -c . || true)
      if (( np_count > 0 )); then result_pass "$id" "$desc"
      else result_fail "$id" "$desc" "No NetworkPolicy objects found in the selected namespace/project" "No NetworkPolicy objects were returned for the selected namespace/project"; fi
    fi
  else
    local all_ns ns_with_np
    all_ns=$(_rcmd "kubectl get namespaces -o jsonpath='{.items[*].metadata.name}'" 2>/dev/null | wc -w)
    ns_with_np=$(_rcmd "kubectl get networkpolicy --all-namespaces -o jsonpath='{range .items[*]}{.metadata.namespace}{\"\\n\"}{end}'" 2>/dev/null | sort -u | wc -l)
    if (( ns_with_np >= all_ns )); then result_pass "$id" "$desc"
    else result_warn "$id" "$desc" "Only $ns_with_np of $all_ns namespace(s) have NetworkPolicies"; fi
  fi

  # 5.4 Secrets Management
  header "5.4 - Secrets Management"

  id="5.4.1"
  desc="Prefer secret files over secret environment variables (Kubernetes/OpenShift policy check)"
  local env_secret_refs
  env_secret_refs=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .spec.containers[*].env[*]}{.name}{":"}{.valueFrom.secretKeyRef.name}{"/"}{.valueFrom.secretKeyRef.key}{" "}{end}{"\n"}{end}'" 2>/dev/null | grep -E ':[^/[:space:]]+/[^[:space:]]+' || true)
  if [[ -z "$env_secret_refs" ]]; then result_pass "$id" "$desc"
  else result_fail "$id" "$desc" "Secrets are injected through environment variables in one or more in-scope pods" "$env_secret_refs"; fi

  id="5.4.2"
  desc="Consider external secret storage (Manual)"
  result_info "$id" "$desc" "Review the secret-management approach used by the in-scope workloads"

  # 5.5 Extensible Admission Control
  header "5.5 - Extensible Admission Control"

  id="5.5.1"
  desc="Configure Image Provenance using ImagePolicyWebhook admission controller (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "Admission controller configuration is cluster-level; namespace mode only"
  else
    local apiserver_proc
    apiserver_proc=$(get_process_args "kube-apiserver" || true)
    if [[ -n "$apiserver_proc" ]]; then
      local adm_plugins
      adm_plugins=$(get_argument_value "$apiserver_proc" "--enable-admission-plugins")
      if echo "$adm_plugins" | grep -qi "ImagePolicyWebhook"; then result_pass "$id" "$desc"
      else result_warn "$id" "$desc" "ImagePolicyWebhook not in --enable-admission-plugins"; fi
    else
      result_info "$id" "$desc" "Review image provenance policy in cluster"
    fi
  fi

  # 5.6 General Policies
  header "5.6 / OpenShift 5.7 - General Policies"

  id="5.6.1"
  desc="Create administrative boundaries between resources using namespaces (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "Requires visibility of namespaces across the cluster; namespace mode only"
  else
    local ns_list ns_count
    ns_list=$(_rcmd "kubectl get namespaces -o jsonpath='{.items[*].metadata.name}'" 2>/dev/null)
    ns_count=$(echo "$ns_list" | wc -w)
    if (( ns_count > 4 )); then result_pass "$id" "$desc"
    else result_info "$id" "$desc" "Only $ns_count namespace(s) found. Consider creating additional namespaces for workload isolation."; fi
  fi

  id="5.6.2"
  desc="Use an appropriate seccomp profile (Kubernetes 5.6 / OpenShift 5.7 policy theme)"
  local seccomp_profiles seccomp_unconfined
  seccomp_profiles=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.securityContext.seccompProfile.type}{"\t"}{range .spec.containers[*]}{.name}{":"}{.securityContext.seccompProfile.type}{" "}{end}{"\n"}{end}'" 2>/dev/null || true)
  seccomp_unconfined=$(printf '%s\n' "$seccomp_profiles" | grep -i 'Unconfined' || true)
  if [[ -n "$seccomp_unconfined" ]]; then
    result_fail "$id" "$desc" "One or more in-scope workloads explicitly use an Unconfined seccomp profile" "$seccomp_unconfined"
  elif printf '%s\n' "$seccomp_profiles" | grep -q 'RuntimeDefault'; then
    result_pass "$id" "$desc"
  else
    result_info "$id" "$desc" "No explicit RuntimeDefault/Unconfined profile found; OpenShift SCC or platform defaults may supply the effective profile"
  fi

  id="5.6.3"
  desc="Apply Security Context to Pods and Containers (Kubernetes 5.6 / OpenShift 5.7 policy theme)"
  local no_sc_pods
  no_sc_pods=$(_rcmd "kubectl get pods $pod_scope -o jsonpath='{range .items[*]}{@.metadata.name}: {.spec.securityContext}{"\n"}{end}'" 2>/dev/null | grep ": $" | wc -l || true)
  if (( no_sc_pods == 0 )); then result_pass "$id" "$desc"
  else result_info "$id" "$desc" "$no_sc_pods pod(s) have no pod-level securityContext; container-level settings and OpenShift SCC defaults may still apply"; fi

  id="5.6.4"
  desc="The default namespace should not be used (Manual)"
  if $ns_mode; then
    result_skip "$id" "$desc" "The default namespace is outside the selected namespace/project scope"
  else
    local default_resources
    default_resources=$(_rcmd "kubectl get all -n default" 2>/dev/null | grep -v "^NAME\\|kubernetes\\|^$" | wc -l || true)
    if (( default_resources == 0 )); then result_pass "$id" "$desc"
    else result_warn "$id" "$desc" "$default_resources resource(s) found in the default namespace"; fi
  fi
}

###############################################################################
# kube-bench Integration (Kubernetes Goat style in-cluster audit)
###############################################################################

KUBE_BENCH_IMAGE="${KUBE_BENCH_IMAGE:-docker.io/aquasec/kube-bench:latest}"
_KB_JOB_PREFIX="kube-audit-bench"

_kb_master_job_yaml() {
  cat <<EOYAML
apiVersion: batch/v1
kind: Job
metadata:
  name: ${_KB_JOB_PREFIX}-master
  labels:
    app: kube-audit-bench
spec:
  backoffLimit: 0
  template:
    metadata:
      labels:
        app: kube-audit-bench
    spec:
      hostPID: true
      nodeSelector:
        node-role.kubernetes.io/control-plane: ""
      tolerations:
        - key: node-role.kubernetes.io/control-plane
          operator: Exists
          effect: NoSchedule
        - key: node-role.kubernetes.io/master
          operator: Exists
          effect: NoSchedule
      containers:
        - name: kube-bench
          image: ${KUBE_BENCH_IMAGE}
          command: ["sh", "-c", "kube-bench run --targets master,etcd --json || true"]
          volumeMounts:
            - name: var-lib-etcd
              mountPath: /var/lib/etcd
              readOnly: true
            - name: var-lib-kubelet
              mountPath: /var/lib/kubelet
              readOnly: true
            - name: var-lib-kube-scheduler
              mountPath: /var/lib/kube-scheduler
              readOnly: true
            - name: var-lib-kube-controller-manager
              mountPath: /var/lib/kube-controller-manager
              readOnly: true
            - name: etc-systemd
              mountPath: /etc/systemd
              readOnly: true
            - name: lib-systemd
              mountPath: /lib/systemd/
              readOnly: true
            - name: srv-kubernetes
              mountPath: /srv/kubernetes/
              readOnly: true
            - name: etc-kubernetes
              mountPath: /etc/kubernetes
              readOnly: true
            - name: usr-bin
              mountPath: /usr/local/mount-from-host/bin
              readOnly: true
            - name: etc-cni-netd
              mountPath: /etc/cni/net.d/
              readOnly: true
            - name: opt-cni-bin
              mountPath: /opt/cni/bin/
              readOnly: true
      restartPolicy: Never
      volumes:
        - name: var-lib-etcd
          hostPath: { path: "/var/lib/etcd" }
        - name: var-lib-kubelet
          hostPath: { path: "/var/lib/kubelet" }
        - name: var-lib-kube-scheduler
          hostPath: { path: "/var/lib/kube-scheduler" }
        - name: var-lib-kube-controller-manager
          hostPath: { path: "/var/lib/kube-controller-manager" }
        - name: etc-systemd
          hostPath: { path: "/etc/systemd" }
        - name: lib-systemd
          hostPath: { path: "/lib/systemd" }
        - name: srv-kubernetes
          hostPath: { path: "/srv/kubernetes" }
        - name: etc-kubernetes
          hostPath: { path: "/etc/kubernetes" }
        - name: usr-bin
          hostPath: { path: "/usr/bin" }
        - name: etc-cni-netd
          hostPath: { path: "/etc/cni/net.d/" }
        - name: opt-cni-bin
          hostPath: { path: "/opt/cni/bin/" }
EOYAML
}

_kb_node_job_yaml() {
  cat <<EOYAML
apiVersion: batch/v1
kind: Job
metadata:
  name: ${_KB_JOB_PREFIX}-node
  labels:
    app: kube-audit-bench
spec:
  backoffLimit: 0
  template:
    metadata:
      labels:
        app: kube-audit-bench
    spec:
      hostPID: true
      containers:
        - name: kube-bench
          image: ${KUBE_BENCH_IMAGE}
          command: ["sh", "-c", "kube-bench run --targets node --json || true"]
          volumeMounts:
            - name: var-lib-kubelet
              mountPath: /var/lib/kubelet
              readOnly: true
            - name: etc-systemd
              mountPath: /etc/systemd
              readOnly: true
            - name: lib-systemd
              mountPath: /lib/systemd/
              readOnly: true
            - name: etc-kubernetes
              mountPath: /etc/kubernetes
              readOnly: true
            - name: etc-cni-netd
              mountPath: /etc/cni/net.d/
              readOnly: true
      restartPolicy: Never
      volumes:
        - name: var-lib-kubelet
          hostPath: { path: "/var/lib/kubelet" }
        - name: etc-systemd
          hostPath: { path: "/etc/systemd" }
        - name: lib-systemd
          hostPath: { path: "/lib/systemd" }
        - name: etc-kubernetes
          hostPath: { path: "/etc/kubernetes" }
        - name: etc-cni-netd
          hostPath: { path: "/etc/cni/net.d/" }
EOYAML
}

# Deploy kube-bench Jobs and wait for completion
run_kube_bench() {
  if ! command -v kubectl &>/dev/null; then
    info "kubectl not found — skipping kube-bench integration"
    return 1
  fi

  info "Deploying kube-bench Jobs (Kubernetes Goat style in-cluster audit)..."

  # Clean up any previous runs
  kubectl delete job "${_KB_JOB_PREFIX}-master" "${_KB_JOB_PREFIX}-node" --ignore-not-found=true &>/dev/null || true

  # Deploy master job
  local master_deployed=false
  if _kb_master_job_yaml | kubectl apply -f - &>/dev/null; then
    master_deployed=true
    info "Deployed kube-bench master Job"
  else
    info "Could not deploy master Job (no control-plane node selector match?)"
  fi

  # Deploy node job
  local node_deployed=false
  if _kb_node_job_yaml | kubectl apply -f - &>/dev/null; then
    node_deployed=true
    info "Deployed kube-bench node Job"
  else
    info "Could not deploy node Job"
  fi

  if ! $master_deployed && ! $node_deployed; then
    info "No kube-bench Jobs deployed — skipping"
    return 1
  fi

  # Wait for completion (up to 5 minutes)
  local timeout=300
  local interval=5
  local elapsed=0
  info "Waiting for kube-bench Jobs to complete (timeout: ${timeout}s)..."

  while (( elapsed < timeout )); do
    local all_done=true
    if $master_deployed; then
      local master_status
      master_status=$(kubectl get job "${_KB_JOB_PREFIX}-master" -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)
      local master_failed
      master_failed=$(kubectl get job "${_KB_JOB_PREFIX}-master" -o jsonpath='{.status.conditions[?(@.type=="Failed")].status}' 2>/dev/null || true)
      if [[ "$master_status" != "True" && "$master_failed" != "True" ]]; then
        all_done=false
      fi
    fi
    if $node_deployed; then
      local node_status
      node_status=$(kubectl get job "${_KB_JOB_PREFIX}-node" -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)
      local node_failed
      node_failed=$(kubectl get job "${_KB_JOB_PREFIX}-node" -o jsonpath='{.status.conditions[?(@.type=="Failed")].status}' 2>/dev/null || true)
      if [[ "$node_status" != "True" && "$node_failed" != "True" ]]; then
        all_done=false
      fi
    fi
    if $all_done; then break; fi
    sleep "$interval"
    (( elapsed += interval )) || true
  done

  if (( elapsed >= timeout )); then
    info "kube-bench Jobs did not complete within ${timeout}s"
  fi

  # Collect results
  local master_json="" node_json=""
  if $master_deployed; then
    local master_pod
    master_pod=$(kubectl get pods -l job-name="${_KB_JOB_PREFIX}-master" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
    if [[ -n "$master_pod" ]]; then
      master_json=$(kubectl logs "$master_pod" 2>/dev/null || true)
      info "Collected kube-bench master results from $master_pod"
    fi
  fi
  if $node_deployed; then
    local node_pod
    node_pod=$(kubectl get pods -l job-name="${_KB_JOB_PREFIX}-node" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
    if [[ -n "$node_pod" ]]; then
      node_json=$(kubectl logs "$node_pod" 2>/dev/null || true)
      info "Collected kube-bench node results from $node_pod"
    fi
  fi

  # Parse and merge results
  if [[ -n "$master_json" ]]; then
    merge_kube_bench_results "$master_json"
  fi
  if [[ -n "$node_json" ]]; then
    merge_kube_bench_results "$node_json"
  fi

  # Clean up Jobs
  kubectl delete job "${_KB_JOB_PREFIX}-master" "${_KB_JOB_PREFIX}-node" --ignore-not-found=true &>/dev/null || true
  info "kube-bench Jobs cleaned up"
}

# Parse kube-bench JSON and merge into ALL_RESULTS, replacing SKIP entries
merge_kube_bench_results() {
  local kb_json="$1"

  # kube-bench JSON has: { "Controls": [ { "tests": [ { "results": [ { "test_number", "status", "test_desc", "remediation" } ] } ] } ] }
  # We need python or jq to parse. Try python3 first, then python, then jq.
  local parser=""
  if command -v python3 &>/dev/null; then
    parser="python3"
  elif command -v python &>/dev/null; then
    parser="python"
  fi

  if [[ -n "$parser" ]]; then
    # Use python to extract results as tab-separated: id\tstatus\tdesc\tremediation
    local parsed
    parsed=$("$parser" -c "
import json, sys
try:
    data = json.loads(sys.stdin.read())
except:
    sys.exit(0)
controls = data.get('Controls', data.get('controls', []))
for ctrl in controls:
    for test in ctrl.get('tests', []):
        for r in test.get('results', []):
            num = r.get('test_number', '')
            status = r.get('status', '').upper()
            desc = r.get('test_desc', '')
            rem = r.get('remediation', '')
            audit = r.get('audit', '')
            actual = r.get('actual_value', '')
            expected = r.get('expected_result', '')
            audit_out = '\n'.join(filter(None, [audit, 'Actual: ' + actual if actual else '', 'Expected: ' + expected if expected else '']))
            print(f'{num}\t{status}\t{desc}\t{rem}\t{audit_out}')
" <<< "$kb_json" 2>/dev/null || true)

    if [[ -z "$parsed" ]]; then return; fi

    local merged_count=0
    while IFS=$'\t' read -r kb_id kb_status kb_desc kb_rem kb_audit; do
      [[ -z "$kb_id" ]] && continue
      # Normalize kube-bench status to our status codes
      case "$kb_status" in
        PASS) kb_status="PASS" ;;
        FAIL) kb_status="FAIL" ;;
        WARN) kb_status="WARN" ;;
        INFO) kb_status="INFO" ;;
        *) continue ;;
      esac

      # Find and replace matching SKIP entries in ALL_RESULTS
      local i=0
      for entry in "${ALL_RESULTS[@]}"; do
        local r_id="${entry%%$'\x1f'*}"
        local r_rest="${entry#*$'\x1f'}"
        local r_result="${r_rest%%$'\x1f'*}"
        if [[ "$r_id" == "$kb_id" && "$r_result" == "SKIP" ]]; then
          # Replace this entry with kube-bench result
          local detail="[kube-bench] $kb_desc"
          local remediation="${kb_rem:-$(get_remediation "$kb_id")}"
          ALL_RESULTS[$i]="${kb_id}${_D}${kb_status}${_D}${kb_desc}${_D}${detail}${_D}${kb_audit}${_D}${remediation}"
          # Update counters
          ((SKIP--)) || true
          case "$kb_status" in
            PASS) ((PASS++)) || true ;;
            FAIL) ((FAIL++)) || true ;;
            WARN) ((WARN++)) || true ;;
            INFO) ((INFO++)) || true ;;
          esac
          ((merged_count++)) || true
          if ! $JSON_OUTPUT; then
            case "$kb_status" in
              PASS) printf "${GREEN}[PASS]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              FAIL) printf "${RED}[FAIL]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              WARN) printf "${YELLOW}[WARN]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              INFO) printf "${BLUE}[INFO]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
            esac
          fi
          break
        fi
        ((i++)) || true
      done
    done <<< "$parsed"

    if ! $JSON_OUTPUT; then
      info "Merged $merged_count kube-bench result(s) into audit (replaced SKIP entries)"
    fi

  elif command -v jq &>/dev/null; then
    # Fallback: use jq
    local parsed
    parsed=$(echo "$kb_json" | jq -r '
      (.Controls // .controls // [])[] |
      .tests[]? | .results[]? |
      [.test_number, (.status | ascii_upcase), .test_desc, .remediation, ((.audit // "") + "\n" + (if .actual_value then "Actual: " + .actual_value else "" end) + "\n" + (if .expected_result then "Expected: " + .expected_result else "" end))] |
      @tsv
    ' 2>/dev/null || true)

    if [[ -z "$parsed" ]]; then return; fi

    local merged_count=0
    while IFS=$'\t' read -r kb_id kb_status kb_desc kb_rem kb_audit; do
      [[ -z "$kb_id" ]] && continue
      case "$kb_status" in
        PASS|FAIL|WARN|INFO) ;;
        *) continue ;;
      esac

      local i=0
      for entry in "${ALL_RESULTS[@]}"; do
        local r_id="${entry%%$'\x1f'*}"
        local r_rest="${entry#*$'\x1f'}"
        local r_result="${r_rest%%$'\x1f'*}"
        if [[ "$r_id" == "$kb_id" && "$r_result" == "SKIP" ]]; then
          local detail="[kube-bench] $kb_desc"
          local remediation="${kb_rem:-$(get_remediation "$kb_id")}"
          ALL_RESULTS[$i]="${kb_id}${_D}${kb_status}${_D}${kb_desc}${_D}${detail}${_D}${kb_audit}${_D}${remediation}"
          ((SKIP--)) || true
          case "$kb_status" in
            PASS) ((PASS++)) || true ;;
            FAIL) ((FAIL++)) || true ;;
            WARN) ((WARN++)) || true ;;
            INFO) ((INFO++)) || true ;;
          esac
          ((merged_count++)) || true
          if ! $JSON_OUTPUT; then
            case "$kb_status" in
              PASS) printf "${GREEN}[PASS]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              FAIL) printf "${RED}[FAIL]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              WARN) printf "${YELLOW}[WARN]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
              INFO) printf "${BLUE}[INFO]${NC} %s %s ${CYAN}(kube-bench)${NC}\n" "$kb_id" "$kb_desc" ;;
            esac
          fi
          break
        fi
        ((i++)) || true
      done
    done <<< "$parsed"

    if ! $JSON_OUTPUT; then
      info "Merged $merged_count kube-bench result(s) into audit (replaced SKIP entries)"
    fi
  else
    info "Cannot parse kube-bench JSON: install python3 or jq"
  fi
}

###############################################################################
# Main
###############################################################################

main() {
  if ! $JSON_OUTPUT; then
    printf "${BOLD}${CYAN}"
    cat <<'BANNER'
 ____  _  ___    _  __     _                          _
/ ___|(_)/ _ \  | |/ /   _| |__   ___ _ __ _ __   ___| |_ ___  ___
| |   | | (_) | | ' / | | | '_ \ / _ \ '__| '_ \ / _ \ __/ _ \/ __|
| |___| |\__, | | . \ |_| | |_) |  __/ |  | | | |  __/ ||  __/\__ \
\____|_|  /_/  |_|\_\__,_|_.__/ \___|_|  |_| |_|\___|\__\___||___/
BANNER
    printf "${NC}\n"
    echo "Kubernetes / OpenShift Security Review Audit Script"
    echo "Failure-focused Kubernetes / OpenShift project review"
    echo "Target: Kubernetes v1.32 - v1.34"
    echo "================================================================"
    echo ""
    echo "Kubernetes Distribution: ${CYAN}${BOLD}$K8S_DISTRO${NC}"
    echo "Running as: $(whoami)"
    echo "Date: $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    if [[ -n "$TARGET_HOST" ]]; then
      echo "Target host: $TARGET_HOST"
    fi
    if [[ -n "$NAMESPACE" ]]; then
      echo "Namespace/project scope: $NAMESPACE"
    fi
    if has_kubectl; then
      local k8s_ver
      k8s_ver=$(_rcmd "kubectl version --short 2>/dev/null | head -1 || kubectl version 2>/dev/null | head -1 || echo unknown")
      echo "Kubernetes: $k8s_ver"
    fi
    echo ""
  fi

  # Run sections based on filters
  if should_run_section "1"; then
    if [[ -z "$FILTER_NODE" || "$FILTER_NODE" == "master" ]]; then
      run_1_1
      run_1_2
      run_1_3
      run_1_4
    fi
  fi

  if should_run_section "2"; then
    if [[ -z "$FILTER_NODE" || "$FILTER_NODE" == "master" ]]; then
      run_2
    fi
  fi

  if should_run_section "3"; then
    if [[ -z "$FILTER_NODE" || "$FILTER_NODE" == "master" ]]; then
      run_3
    fi
  fi

  if should_run_section "4"; then
    if [[ -z "$FILTER_NODE" || "$FILTER_NODE" == "worker" || -z "$FILTER_NODE" ]]; then
      run_4_1
      run_4_2
      run_4_3
    fi
  fi

  if should_run_section "5"; then
    run_5
  fi

  # kube-bench integration: deploy in-cluster Jobs and merge results
  if $KUBE_BENCH; then
    if ! $JSON_OUTPUT; then
      echo ""
      header "kube-bench In-Cluster Audit"
    fi
    run_kube_bench || true
  fi

  # Summary
  if $JSON_OUTPUT; then
    # Remove trailing comma and close array
    JSON_RESULTS="${JSON_RESULTS%,}]"
    cat <<EOF
{
  "benchmark": "Kubernetes / OpenShift security review (benchmark-informed)",
  "date": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "summary": {
    "total": $TOTAL,
    "pass": $PASS,
    "fail": $FAIL,
    "warn": $WARN,
    "info": $INFO,
    "skip": $SKIP
  },
  "results": $JSON_RESULTS
}
EOF
  else
    echo ""
    echo "================================================================"
    printf "${BOLD}Summary${NC}\n"
    echo "================================================================"
    printf "Total checks:  %d\n" "$TOTAL"
    printf "${GREEN}Pass:          %d${NC}\n" "$PASS"
    printf "${RED}Fail:          %d${NC}\n" "$FAIL"
    printf "${YELLOW}Warn:          %d${NC}\n" "$WARN"
    printf "${BLUE}Info:          %d${NC}\n" "$INFO"
    printf "${YELLOW}Skip:          %d${NC}\n" "$SKIP"
    echo "================================================================"

    if (( FAIL > 0 )); then
      printf "\n${RED}${BOLD}%d check(s) FAILED. Review the results above for remediation.${NC}\n" "$FAIL"
    else
      printf "\n${GREEN}${BOLD}No explicit failures detected by the checks that could be evaluated.${NC}\n"
    fi
    if (( WARN > 0 )); then
      printf "${YELLOW}%d check(s) need manual review.${NC}\n" "$WARN"
    fi
    if (( FAIL > 0 )); then
      echo ""
      printf "${RED}${BOLD}Explicit failures (quick triage):${NC}\n"
      for entry in "${ALL_RESULTS[@]}"; do
        local r_id r_result r_desc r_detail r_audit r_remediation
        _parse_entry "$entry"
        if [[ "$r_result" == "FAIL" ]]; then
          printf "${RED}[FAIL]${NC} %s %s\n" "$r_id" "$r_desc"
          [[ -n "$r_detail" ]] && printf "       %s\n" "$r_detail"
        fi
      done
    fi
  fi

  # Write file-based reports if --output was specified
  if [[ -n "$OUTPUT_DIR" ]]; then
    mkdir -p "$OUTPUT_DIR"
    write_json_report "$OUTPUT_DIR/cis_benchmark.json"
    write_csv_report  "$OUTPUT_DIR/cis_benchmark.csv"
    write_html_report "$OUTPUT_DIR/cis_benchmark.html"
    write_failures_report "$OUTPUT_DIR/failures.txt"
    if ! $JSON_OUTPUT; then
      echo ""
      echo "Reports written to:"
      echo "  FAILURES: $OUTPUT_DIR/failures.txt"
      echo "  JSON:     $OUTPUT_DIR/cis_benchmark.json"
      echo "  CSV:      $OUTPUT_DIR/cis_benchmark.csv"
      echo "  HTML:     $OUTPUT_DIR/cis_benchmark.html"
    fi
  fi

  # Post-execution launch options
  if $LAUNCH_K9S; then
    echo ""
    echo "================================================================"
    echo "Launching k9s..."
    echo "================================================================"
    k9s_opts=()
    if [[ -n "$KUBECONFIG_PATH" ]]; then
      k9s_opts+=("--kubeconfig" "$KUBECONFIG_PATH")
    fi
    if [[ -n "$KUBECONTEXT" ]]; then
      k9s_opts+=("--context" "$KUBECONTEXT")
    fi
    k9s "${k9s_opts[@]}" || true
  elif $LAUNCH_KUBECTL; then
    echo ""
    echo "================================================================"
    echo "Launching interactive kubectl shell..."
    echo "================================================================"
    (
      if [[ -n "$KUBECONFIG_PATH" ]]; then
        export KUBECONFIG="$KUBECONFIG_PATH"
      fi
      local k_bin="${KUBE_CMD:-kubectl}"
      if [[ -n "$KUBECONTEXT" ]]; then
        alias kubectl="$k_bin --context=$KUBECONTEXT"
        alias k="$k_bin --context=$KUBECONTEXT"
      else
        alias kubectl="$k_bin"
        alias k="$k_bin"
      fi
      echo "Type 'exit' to return to normal terminal."
      bash -i
    )
  fi
}

###############################################################################
# Output Generators
###############################################################################

# Parse pipe-delimited ALL_RESULTS entry using parameter expansion (handles newlines)
_parse_entry() {
  local _rest="$1"
  r_id="${_rest%%$'\x1f'*}";     _rest="${_rest#*$'\x1f'}"
  r_result="${_rest%%$'\x1f'*}";  _rest="${_rest#*$'\x1f'}"
  r_desc="${_rest%%$'\x1f'*}";    _rest="${_rest#*$'\x1f'}"
  r_detail="${_rest%%$'\x1f'*}";  _rest="${_rest#*$'\x1f'}"
  r_audit="${_rest%%$'\x1f'*}";   _rest="${_rest#*$'\x1f'}"
  r_remediation="$_rest"
}

# Escape a string for safe embedding in JSON
json_escape() {
  local s="$1"
  s="${s//\\/\\\\}"
  s="${s//\"/\\\"}"
  s="${s//$'\n'/\\n}"
  s="${s//$'\r'/\\r}"
  s="${s//$'\t'/\\t}"
  printf '%s' "$s"
}

write_json_report() {
  local outfile="$1"
  {
    printf '{\n'
    printf '  "benchmark": "Kubernetes / OpenShift security review (benchmark-informed)",\n'
    printf '  "date": "%s",\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    printf '  "summary": {\n'
    printf '    "total": %d,\n' "$TOTAL"
    printf '    "pass": %d,\n' "$PASS"
    printf '    "fail": %d,\n' "$FAIL"
    printf '    "warn": %d,\n' "$WARN"
    printf '    "info": %d,\n' "$INFO"
    printf '    "skip": %d\n' "$SKIP"
    printf '  },\n'
    printf '  "results": [\n'

    local i=0
    local count=${#ALL_RESULTS[@]}
    for entry in "${ALL_RESULTS[@]}"; do
      ((i++)) || true
      local r_id r_result r_desc r_detail r_audit r_remediation
      _parse_entry "$entry"

      printf '    {\n'
      printf '      "id": "%s",\n' "$(json_escape "$r_id")"
      printf '      "result": "%s",\n' "$(json_escape "$r_result")"
      printf '      "description": "%s",\n' "$(json_escape "$r_desc")"
      printf '      "detail": "%s"' "$(json_escape "$r_detail")"
      if [[ -n "$r_audit" ]]; then
        printf ',\n      "audit_output": "%s"' "$(json_escape "$r_audit")"
      fi
      if [[ -n "$r_remediation" ]]; then
        printf ',\n      "remediation": "%s"' "$(json_escape "$r_remediation")"
      fi
      if (( i < count )); then
        printf '\n    },\n'
      else
        printf '\n    }\n'
      fi
    done

    printf '  ]\n'
    printf '}\n'
  } > "$outfile"
}

# Escape a field for safe embedding in CSV (RFC 4180)
csv_escape() {
  local s="$1"
  if [[ "$s" == *[,\"$'\n']* ]]; then
    s="${s//\"/\"\"}"
    printf '"%s"' "$s"
  else
    printf '%s' "$s"
  fi
}

write_csv_report() {
  local outfile="$1"
  {
    echo "ID,Result,Description,Detail,Audit Output,Remediation"
    for entry in "${ALL_RESULTS[@]}"; do
      local r_id r_result r_desc r_detail r_audit r_remediation
      _parse_entry "$entry"

      printf '%s,%s,%s,%s,%s,%s\n' \
        "$(csv_escape "$r_id")" \
        "$(csv_escape "$r_result")" \
        "$(csv_escape "$r_desc")" \
        "$(csv_escape "$r_detail")" \
        "$(csv_escape "$r_audit")" \
        "$(csv_escape "$r_remediation")"
    done
  } > "$outfile"
}

write_failures_report() {
  local outfile="$1"
  {
    echo "Kubernetes / OpenShift Project Security Review - Explicit Failures"
    echo "Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    echo "Namespace/Project: ${NAMESPACE:-cluster-wide}"
    echo ""
    if (( FAIL == 0 )); then
      echo "No explicit failures detected by checks that could be evaluated."
    else
      for entry in "${ALL_RESULTS[@]}"; do
        local r_id r_result r_desc r_detail r_audit r_remediation
        _parse_entry "$entry"
        [[ "$r_result" == "FAIL" ]] || continue
        echo "[FAIL] $r_id - $r_desc"
        [[ -n "$r_detail" ]] && echo "  $r_detail"
        if [[ -n "$r_audit" ]]; then
          echo "  Evidence:"
          while IFS= read -r line; do echo "    $line"; done <<< "$r_audit"
        fi
        echo ""
      done
    fi
  } > "$outfile"
}

# Escape a string for safe embedding in HTML
html_escape() {
  local s="$1"
  s="${s//&/\&amp;}"
  s="${s//</\&lt;}"
  s="${s//>/\&gt;}"
  printf '%s' "$s"
}

write_html_report() {
  local outfile="$1"
  local run_date
  run_date=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  {
    cat <<'HTMLHEAD'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kubernetes / OpenShift Security Review // AUDIT REPORT</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&display=swap');

  :root {
    --bg-dark: #0a0a0f;
    --bg-panel: #0d0f1a;
    --bg-card: #111327;
    --bg-hover: #161938;
    --border-glow: #00f0ff;
    --neon-cyan: #00f0ff;
    --neon-magenta: #ff2a6d;
    --neon-yellow: #ffd300;
    --neon-green: #05ffa1;
    --neon-purple: #b967ff;
    --neon-orange: #ff6e27;
    --text-primary: #e0e6f0;
    --text-dim: #5a6088;
    --pass: #05ffa1;
    --fail: #ff2a6d;
    --warn: #ffd300;
    --info: #00f0ff;
    --skip: #5a6088;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Rajdhani', 'Segoe UI', sans-serif;
    background: var(--bg-dark);
    color: var(--text-primary);
    line-height: 1.6;
    padding: 2rem;
    min-height: 100vh;
    background-image:
      radial-gradient(ellipse at 20% 50%, rgba(0, 240, 255, 0.03) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 20%, rgba(255, 42, 109, 0.03) 0%, transparent 50%),
      radial-gradient(ellipse at 50% 80%, rgba(185, 103, 255, 0.02) 0%, transparent 50%);
  }

  .scanline {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: repeating-linear-gradient(
      0deg, transparent, transparent 2px,
      rgba(0, 240, 255, 0.008) 2px, rgba(0, 240, 255, 0.008) 4px
    );
    pointer-events: none; z-index: 9999;
  }

  .container { max-width: 1500px; margin: 0 auto; position: relative; }

  .header {
    border: 1px solid rgba(0, 240, 255, 0.2);
    background: linear-gradient(135deg, var(--bg-panel) 0%, rgba(0, 240, 255, 0.05) 100%);
    border-radius: 4px;
    padding: 2rem 2.5rem;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
  }
  .header::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 2px;
    background: linear-gradient(90deg, transparent, var(--neon-cyan), var(--neon-magenta), transparent);
  }
  .header::after {
    content: '// SYSTEM AUDIT';
    position: absolute; top: 1rem; right: 1.5rem;
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.7rem;
    color: var(--neon-cyan);
    opacity: 0.4;
    letter-spacing: 2px;
  }

  h1 {
    font-family: 'Orbitron', monospace;
    font-size: 1.6rem;
    font-weight: 900;
    letter-spacing: 3px;
    text-transform: uppercase;
    background: linear-gradient(90deg, var(--neon-cyan), var(--neon-magenta));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.3rem;
    text-shadow: 0 0 30px rgba(0, 240, 255, 0.3);
  }
  .subtitle {
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.85rem;
    color: var(--text-dim);
    letter-spacing: 1px;
  }

  .meta {
    font-family: 'Share Tech Mono', monospace;
    color: var(--neon-cyan);
    margin-bottom: 0;
    font-size: 0.8rem;
    opacity: 0.7;
    margin-top: 0.8rem;
  }

  /* Summary Cards */
  .summary { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 2rem; }
  .summary-card {
    padding: 1.2rem 1.8rem;
    border-radius: 4px;
    background: var(--bg-card);
    border: 1px solid rgba(0, 240, 255, 0.1);
    min-width: 130px;
    text-align: center;
    position: relative;
    transition: all 0.3s ease;
  }
  .summary-card:hover {
    border-color: rgba(0, 240, 255, 0.4);
    box-shadow: 0 0 20px rgba(0, 240, 255, 0.1);
    transform: translateY(-2px);
  }
  .summary-card .count {
    font-family: 'Orbitron', monospace;
    font-size: 2.2rem;
    font-weight: 700;
    line-height: 1;
  }
  .summary-card .label {
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.7rem;
    text-transform: uppercase;
    color: var(--text-dim);
    letter-spacing: 2px;
    margin-top: 0.4rem;
  }
  .summary-card.total .count { color: var(--text-primary); }
  .summary-card.total { border-color: rgba(224, 230, 240, 0.15); }
  .summary-card.pass .count { color: var(--pass); text-shadow: 0 0 15px rgba(5, 255, 161, 0.4); }
  .summary-card.pass { border-color: rgba(5, 255, 161, 0.2); }
  .summary-card.fail .count { color: var(--fail); text-shadow: 0 0 15px rgba(255, 42, 109, 0.4); }
  .summary-card.fail { border-color: rgba(255, 42, 109, 0.2); }
  .summary-card.warn .count { color: var(--warn); text-shadow: 0 0 15px rgba(255, 211, 0, 0.4); }
  .summary-card.warn { border-color: rgba(255, 211, 0, 0.2); }
  .summary-card.info .count { color: var(--info); text-shadow: 0 0 15px rgba(0, 240, 255, 0.4); }
  .summary-card.info { border-color: rgba(0, 240, 255, 0.2); }
  .summary-card.skip .count { color: var(--skip); }
  .summary-card.skip { border-color: rgba(90, 96, 136, 0.2); }

  /* Filters */
  .filters {
    margin-bottom: 1.5rem;
    display: flex;
    gap: 1rem;
    align-items: center;
  }
  .filters input {
    padding: 0.6rem 1rem;
    background: var(--bg-card);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 2px;
    color: var(--text-primary);
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.85rem;
    width: 350px;
    transition: border-color 0.3s;
  }
  .filters input:focus {
    outline: none;
    border-color: var(--neon-cyan);
    box-shadow: 0 0 10px rgba(0, 240, 255, 0.15);
  }
  .filters input::placeholder { color: var(--text-dim); }
  .filters select {
    padding: 0.6rem 1rem;
    background: var(--bg-card);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 2px;
    color: var(--text-primary);
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.85rem;
    cursor: pointer;
  }
  .filters select:focus {
    outline: none;
    border-color: var(--neon-cyan);
  }

  /* Table */
  table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    background: var(--bg-panel);
    border: 1px solid rgba(0, 240, 255, 0.1);
    border-radius: 4px;
    overflow: hidden;
  }
  col.col-id { width: 6%; }
  col.col-status { width: 7%; }
  col.col-desc { width: 25%; }
  col.col-detail { width: 30%; }
  col.col-remediation { width: 32%; }
  thead th {
    background: linear-gradient(180deg, #141730 0%, #0d0f1a 100%);
    color: var(--neon-cyan);
    padding: 0.85rem 1rem;
    text-align: left;
    font-family: 'Orbitron', monospace;
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 2px;
    position: sticky;
    top: 0;
    cursor: pointer;
    border-bottom: 1px solid rgba(0, 240, 255, 0.2);
    z-index: 10;
  }
  thead th:hover { color: #fff; text-shadow: 0 0 10px var(--neon-cyan); }
  thead th::after {
    content: ' \25B8';
    opacity: 0.3;
    font-size: 0.6rem;
  }
  tbody tr {
    border-bottom: 1px solid rgba(0, 240, 255, 0.04);
    transition: background 0.2s;
  }
  tbody tr:hover { background: var(--bg-hover); }
  td {
    padding: 0.7rem 1rem;
    font-size: 0.9rem;
    vertical-align: top;
    font-family: 'Rajdhani', sans-serif;
    overflow: hidden;
    word-break: break-all;
    overflow-wrap: break-word;
  }
  td:first-child {
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.85rem;
    color: var(--neon-cyan);
    white-space: nowrap;
  }
  td:nth-child(3) {
    word-break: break-word;
  }

  /* Badges */
  .badge {
    display: inline-block;
    padding: 0.2rem 0.7rem;
    border-radius: 2px;
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.7rem;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
  }
  .badge-pass {
    color: var(--pass);
    background: rgba(5, 255, 161, 0.1);
    border: 1px solid rgba(5, 255, 161, 0.3);
    text-shadow: 0 0 8px rgba(5, 255, 161, 0.4);
  }
  .badge-fail {
    color: var(--fail);
    background: rgba(255, 42, 109, 0.1);
    border: 1px solid rgba(255, 42, 109, 0.3);
    text-shadow: 0 0 8px rgba(255, 42, 109, 0.4);
  }
  .badge-warn {
    color: var(--warn);
    background: rgba(255, 211, 0, 0.1);
    border: 1px solid rgba(255, 211, 0, 0.3);
    text-shadow: 0 0 8px rgba(255, 211, 0, 0.4);
  }
  .badge-info {
    color: var(--info);
    background: rgba(0, 240, 255, 0.1);
    border: 1px solid rgba(0, 240, 255, 0.3);
    text-shadow: 0 0 8px rgba(0, 240, 255, 0.4);
  }
  .badge-skip {
    color: var(--skip);
    background: rgba(90, 96, 136, 0.1);
    border: 1px solid rgba(90, 96, 136, 0.3);
  }

  /* Detail column */
  .detail {
    color: var(--text-dim);
    font-size: 0.8rem;
    font-family: 'Share Tech Mono', monospace;
    display: block;
    word-break: break-all;
    overflow-wrap: break-word;
    line-height: 1.5;
  }

  /* Remediation column */
  .remediation {
    color: var(--neon-yellow);
    font-size: 0.8rem;
    font-family: 'Share Tech Mono', monospace;
    display: block;
    word-break: break-word;
    overflow-wrap: break-word;
    line-height: 1.5;
  }

  /* Audit output toggle */
  .audit-toggle {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    color: var(--neon-cyan);
    cursor: pointer;
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    text-decoration: none;
    padding: 0.25rem 0.5rem;
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 2px;
    background: rgba(0, 240, 255, 0.03);
    transition: all 0.2s;
    margin-top: 0.4rem;
  }
  .audit-toggle:hover {
    background: rgba(0, 240, 255, 0.1);
    border-color: var(--neon-cyan);
    text-shadow: 0 0 8px var(--neon-cyan);
  }
  .audit-toggle::before { content: '\25B6 '; font-size: 0.6rem; }
  .audit-toggle.open::before { content: '\25BC '; }

  /* Audit output content block */
  .audit-content {
    display: none;
    margin-top: 0.6rem;
    border: 1px solid rgba(0, 240, 255, 0.15);
    border-left: 3px solid var(--neon-magenta);
    border-radius: 2px;
    background: rgba(0, 0, 0, 0.4);
    overflow: hidden;
  }
  .audit-content.open { display: block; }
  .audit-content-header {
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.65rem;
    color: var(--neon-magenta);
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 0.4rem 0.8rem;
    background: rgba(255, 42, 109, 0.05);
    border-bottom: 1px solid rgba(0, 240, 255, 0.08);
  }
  .audit-content pre {
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.8rem;
    line-height: 1.6;
    color: #c0c8e0;
    padding: 0.8rem 1rem;
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
    overflow-x: auto;
    max-height: 400px;
    overflow-y: auto;
    tab-size: 4;
  }
  .audit-content pre::-webkit-scrollbar { width: 6px; height: 6px; }
  .audit-content pre::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); }
  .audit-content pre::-webkit-scrollbar-thumb { background: rgba(0, 240, 255, 0.2); border-radius: 3px; }

  /* Fail rows get a subtle left glow */
  tr[data-result="FAIL"] { background: rgba(255, 42, 109, 0.03); }
  tr[data-result="FAIL"]:hover { background: rgba(255, 42, 109, 0.08); }

  /* Custom scrollbar for body */
  ::-webkit-scrollbar { width: 8px; }
  ::-webkit-scrollbar-track { background: var(--bg-dark); }
  ::-webkit-scrollbar-thumb { background: rgba(0, 240, 255, 0.15); border-radius: 4px; }
  ::-webkit-scrollbar-thumb:hover { background: rgba(0, 240, 255, 0.3); }

  @media (max-width: 768px) {
    body { padding: 1rem; }
    .filters { flex-direction: column; }
    .filters input { width: 100%; }
    h1 { font-size: 1.1rem; }
    .summary-card { min-width: 90px; padding: 0.8rem 1rem; }
    .summary-card .count { font-size: 1.6rem; }
  }
</style>
</head>
<body>
<div class="scanline"></div>
<div class="container">
<div class="header">
  <h1>Kubernetes / OpenShift Security Review</h1>
  <div class="subtitle">v1.12.0 // Security Compliance Audit Report</div>
HTMLHEAD

    printf '  <p class="meta">&gt; scan.timestamp: %s</p>\n' "$run_date"
    printf '</div>\n'

    # Summary cards
    printf '<div class="summary">\n'
    printf '<div class="summary-card total"><div class="count">%d</div><div class="label">Total</div></div>\n' "$TOTAL"
    printf '<div class="summary-card pass"><div class="count">%d</div><div class="label">Pass</div></div>\n' "$PASS"
    printf '<div class="summary-card fail"><div class="count">%d</div><div class="label">Fail</div></div>\n' "$FAIL"
    printf '<div class="summary-card warn"><div class="count">%d</div><div class="label">Warn</div></div>\n' "$WARN"
    printf '<div class="summary-card info"><div class="count">%d</div><div class="label">Info</div></div>\n' "$INFO"
    printf '<div class="summary-card skip"><div class="count">%d</div><div class="label">Skip</div></div>\n' "$SKIP"
    printf '</div>\n'

    # Filter controls
    cat <<'HTMLFILTER'
<div class="filters">
  <input type="text" id="searchBox" placeholder="> search by ID or description..." onkeyup="filterTable()">
  <select id="resultFilter" onchange="filterTable()">
    <option value="">// ALL RESULTS</option>
    <option value="PASS">PASS</option>
    <option value="FAIL">FAIL</option>
    <option value="WARN">WARN</option>
    <option value="INFO">INFO</option>
    <option value="SKIP">SKIP</option>
  </select>
</div>
HTMLFILTER

    # Table
    printf '<table id="resultsTable">\n'
    printf '<colgroup><col class="col-id"><col class="col-status"><col class="col-desc"><col class="col-detail"><col class="col-remediation"></colgroup>\n'
    printf '<thead>\n<tr>\n'
    printf '  <th onclick="sortTable(0)">ID</th>\n'
    printf '  <th onclick="sortTable(1)">Status</th>\n'
    printf '  <th onclick="sortTable(2)">Description</th>\n'
    printf '  <th>Detail / Audit</th>\n'
    printf '  <th onclick="sortTable(4)">Remediation</th>\n'
    printf '</tr>\n</thead>\n<tbody>\n'

    local row_idx=0
    for entry in "${ALL_RESULTS[@]}"; do
      local r_id r_result r_desc r_detail r_audit r_remediation
      _parse_entry "$entry"

      local badge_class
      case "$r_result" in
        PASS) badge_class="badge-pass" ;;
        FAIL) badge_class="badge-fail" ;;
        WARN) badge_class="badge-warn" ;;
        INFO) badge_class="badge-info" ;;
        *)    badge_class="badge-skip" ;;
      esac

      printf '<tr data-result="%s">\n' "$r_result"
      printf '  <td>%s</td>\n' "$(html_escape "$r_id")"
      printf '  <td><span class="badge %s">%s</span></td>\n' "$badge_class" "$r_result"
      printf '  <td>%s</td>\n' "$(html_escape "$r_desc")"
      printf '  <td>'
      if [[ -n "$r_detail" ]]; then
        printf '<span class="detail">%s</span>' "$(html_escape "$r_detail")"
      fi
      if [[ -n "$r_audit" ]]; then
        local toggle_label="Audit Output" audit_header="// raw audit data"
        if [[ "$r_result" == "WARN" || "$r_result" == "INFO" || "$r_result" == "SKIP" ]]; then
          toggle_label="Manual Audit"
          audit_header="// how to check manually"
        fi
        printf '<br><span class="audit-toggle" onclick="toggleAudit(%d)">%s</span>' "$row_idx" "$toggle_label"
        printf '<div class="audit-content" id="audit-%d">' "$row_idx"
        printf '<div class="audit-content-header">%s</div>' "$audit_header"
        printf '<pre>%s</pre>' "$(html_escape "$r_audit")"
        printf '</div>'
      fi
      printf '</td>\n'
      printf '  <td><span class="remediation">%s</span></td>\n' "$(html_escape "$r_remediation")"
      printf '</tr>\n'
      ((row_idx++)) || true
    done

    printf '</tbody>\n</table>\n'

    # JavaScript for filtering, sorting, and toggle
    cat <<'HTMLJS'
<script>
function filterTable() {
  var search = document.getElementById('searchBox').value.toLowerCase();
  var result = document.getElementById('resultFilter').value;
  var rows = document.querySelectorAll('#resultsTable tbody tr');
  rows.forEach(function(row) {
    var text = row.textContent.toLowerCase();
    var rowResult = row.getAttribute('data-result');
    var matchSearch = !search || text.indexOf(search) !== -1;
    var matchResult = !result || rowResult === result;
    row.style.display = (matchSearch && matchResult) ? '' : 'none';
  });
}
function toggleAudit(idx) {
  var el = document.getElementById('audit-' + idx);
  el.classList.toggle('open');
  var toggle = el.previousElementSibling;
  toggle.classList.toggle('open');
  toggle.textContent = el.classList.contains('open') ? 'Hide Audit Output' : 'Audit Output';
}
function sortTable(col) {
  var table = document.getElementById('resultsTable');
  var rows = Array.from(table.tBodies[0].rows);
  var asc = table.getAttribute('data-sort-col') == col && table.getAttribute('data-sort-dir') !== 'asc';
  rows.sort(function(a, b) {
    var aText = a.cells[col].textContent.trim();
    var bText = b.cells[col].textContent.trim();
    return asc ? aText.localeCompare(bText, undefined, {numeric: true})
               : bText.localeCompare(aText, undefined, {numeric: true});
  });
  rows.forEach(function(row) { table.tBodies[0].appendChild(row); });
  table.setAttribute('data-sort-col', col);
  table.setAttribute('data-sort-dir', asc ? 'asc' : 'desc');
}
</script>
HTMLJS

    printf '</div>\n</body>\n</html>\n'
  } > "$outfile"
}

main
